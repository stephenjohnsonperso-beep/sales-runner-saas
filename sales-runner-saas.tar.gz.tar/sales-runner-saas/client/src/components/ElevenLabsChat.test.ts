import { describe, expect, it, beforeEach, vi } from "vitest";

describe("ElevenLabsChat Component", () => {
  beforeEach(() => {
    // Clear all mocks before each test
    vi.clearAllMocks();
  });

  it("should load the 11 Labs script when component mounts", () => {
    const createElementSpy = vi.spyOn(document, "createElement");
    const appendChildSpy = vi.spyOn(document.head, "appendChild");

    // Simulate component mount
    const script = document.createElement("script");
    script.src = "https://elevenlabs.io/convai-widget/index.js";
    script.async = true;
    document.head.appendChild(script);

    expect(createElementSpy).toHaveBeenCalledWith("script");
    expect(appendChildSpy).toHaveBeenCalledWith(script);
    expect(script.src).toBe("https://elevenlabs.io/convai-widget/index.js");
    expect(script.async).toBe(true);

    createElementSpy.mockRestore();
    appendChildSpy.mockRestore();
  });

  it("should handle missing agent ID gracefully", () => {
    const consoleWarnSpy = vi.spyOn(console, "warn");

    // Simulate missing agent ID
    const agentId = undefined;
    if (!agentId) {
      console.warn(
        "[11 Labs Chat] Agent ID not provided. Set VITE_ELEVENLABS_AGENT_ID environment variable or pass agentId prop."
      );
    }

    expect(consoleWarnSpy).toHaveBeenCalledWith(
      expect.stringContaining("Agent ID not provided")
    );

    consoleWarnSpy.mockRestore();
  });

  it("should use environment variable when agentId prop is not provided", () => {
    const testAgentId = "test-agent-123";
    process.env.VITE_ELEVENLABS_AGENT_ID = testAgentId;

    const finalAgentId = undefined || process.env.VITE_ELEVENLABS_AGENT_ID;

    expect(finalAgentId).toBe(testAgentId);
  });

  it("should prioritize prop over environment variable", () => {
    const propAgentId = "prop-agent-123";
    const envAgentId = "env-agent-456";
    process.env.VITE_ELEVENLABS_AGENT_ID = envAgentId;

    const finalAgentId = propAgentId || process.env.VITE_ELEVENLABS_AGENT_ID;

    expect(finalAgentId).toBe(propAgentId);
  });

  it("should set correct z-index for widget positioning", () => {
    const containerStyle = {
      position: "fixed",
      bottom: "20px",
      right: "20px",
      zIndex: 9999,
    };

    expect(containerStyle.zIndex).toBe(9999);
    expect(containerStyle.position).toBe("fixed");
    expect(containerStyle.bottom).toBe("20px");
    expect(containerStyle.right).toBe("20px");
  });

  it("should initialize ElevenLabsConvAI with agent ID after script loads", () => {
    const mockSetAgentId = vi.fn();
    (window as any).ElevenLabsConvAI = {
      setAgentId: mockSetAgentId,
    };

    const agentId = "test-agent-123";
    if (window.ElevenLabsConvAI) {
      window.ElevenLabsConvAI.setAgentId(agentId);
    }

    expect(mockSetAgentId).toHaveBeenCalledWith(agentId);
  });

  it("should clean up script on component unmount", () => {
    const script = document.createElement("script");
    script.src = "https://elevenlabs.io/convai-widget/index.js";
    document.head.appendChild(script);

    const removeChildSpy = vi.spyOn(document.head, "removeChild");

    // Simulate component unmount cleanup
    if (script.parentNode) {
      script.parentNode.removeChild(script);
    }

    expect(removeChildSpy).toHaveBeenCalledWith(script);

    removeChildSpy.mockRestore();
  });
});
