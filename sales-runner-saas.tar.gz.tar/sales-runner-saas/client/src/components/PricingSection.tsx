import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check } from "lucide-react";
import { CheckoutButton } from "./CheckoutButton";
import { useLanguage } from "@/contexts/LanguageContext";
import { t } from "@/lib/i18n";

interface PricingTier {
  name: string;
  price: string;
  period: string;
  tagline: string;
  badge?: string;
  features: string[];
  cta: string;
  highlighted?: boolean;
}

export function PricingSection() {
  const { language } = useLanguage();

  const pricingTiers: PricingTier[] = [
    {
      name: t(language, 'pricing.starter'),
      price: language === 'fr' ? '97 $' : '$97',
      period: t(language, 'pricing.monthlyBilling'),
      tagline: language === 'fr' 
        ? "Parfait pour les professionnels de la vente indépendants"
        : "Perfect for independent sales professionals",
      features: [
        language === 'fr' 
          ? "2 heures de génération IA par mois"
          : "2 hours of AI generation per month",
        language === 'fr' 
          ? "Rapports court-forme (5-7 pages)"
          : "Short-form reports (5-7 pages)",
        language === 'fr' 
          ? "6-10 leads qualifiés par mois"
          : "6-10 qualified leads per month",
        language === 'fr' 
          ? "Aperçu de l'entreprise et contacts clés"
          : "Company overview and key contacts",
        language === 'fr' 
          ? "Recommandations d'approche basiques"
          : "Basic outreach recommendations",
        language === 'fr' 
          ? "Livraison par email en 12-14 minutes"
          : "Email delivery in 12-14 minutes",
        language === 'fr' 
          ? "Pour 1 utilisateur"
          : "For 1 user",
        language === 'fr' 
          ? "Support par email"
          : "Email support",
        language === 'fr' 
          ? "Tous les secteurs industriels"
          : "All industrial sectors",
      ],
      cta: language === 'fr' ? "Commencer l'essai gratuit" : "Start Free Trial",
    },
    {
      name: t(language, 'pricing.professional'),
      price: language === 'fr' ? '197 $' : '$197',
      period: t(language, 'pricing.monthlyBilling'),
      tagline: language === 'fr' 
        ? "Pour les équipes de vente en croissance"
        : "For growing sales teams",
      badge: language === 'fr' ? "PLUS POPULAIRE" : "MOST POPULAR",
      features: [
        language === 'fr' 
          ? "6 heures de génération IA par mois"
          : "6 hours of AI generation per month",
        language === 'fr' 
          ? "Rapports détaillés étendus (15-20 pages)"
          : "Extended detailed reports (15-20 pages)",
        language === 'fr' 
          ? "20-30 leads qualifiés par mois"
          : "20-30 qualified leads per month",
        language === 'fr' 
          ? "Intelligence approfondie sur l'entreprise et profils des décideurs"
          : "Deep company intelligence and decision-maker profiles",
        language === 'fr' 
          ? "Stratégies d'approche détaillées et points de discussion"
          : "Detailed outreach strategies and talking points",
        language === 'fr' 
          ? "Récupération d'informations sur les produits techniques"
          : "Technical product information retrieval",
        language === 'fr' 
          ? "Analyse du paysage concurrentiel"
          : "Competitive landscape analysis",
        language === 'fr' 
          ? "Pour jusqu'à 3 utilisateurs"
          : "For up to 3 users",
        language === 'fr' 
          ? "Livraison prioritaire par email (10-12 minutes)"
          : "Priority email delivery (10-12 minutes)",
        language === 'fr' 
          ? "Support prioritaire"
          : "Priority support",
        language === 'fr' 
          ? "Tous les secteurs industriels + ciblage personnalisé"
          : "All industrial sectors + custom targeting",
      ],
      cta: language === 'fr' ? "Commencer l'essai gratuit" : "Start Free Trial",
      highlighted: true,
    },
    {
      name: t(language, 'pricing.enterprise'),
      price: t(language, 'pricing.enterprisePrice'),
      period: "",
      tagline: language === 'fr' 
        ? "Contrôle et personnalisation ultimes"
        : "Ultimate control and customization",
      badge: language === 'fr' ? "PREMIUM" : "PREMIUM",
      features: [
        language === 'fr' 
          ? "Déploiement sur site (LLM local)"
          : "On-premise deployment (local LLM)",
        language === 'fr' 
          ? "Heures de génération de leads illimitées"
          : "Unlimited lead generation hours",
        language === 'fr' 
          ? "Modèles IA entièrement personnalisés formés sur vos données"
          : "Fully custom AI models trained on your data",
        language === 'fr' 
          ? "Solution white-label disponible"
          : "White-label solution available",
        language === 'fr' 
          ? "Confidentialité et sécurité complètes des données"
          : "Complete data privacy and security",
        language === 'fr' 
          ? "Formats de rapport personnalisés et marque"
          : "Custom report formats and branding",
        language === 'fr' 
          ? "Intégration avec vos outils CRM/ventes"
          : "Integration with your CRM/sales tools",
        language === 'fr' 
          ? "Accès API pour l'automatisation"
          : "API access for automation",
        language === 'fr' 
          ? "Gestionnaire de compte dédié"
          : "Dedicated account manager",
        language === 'fr' 
          ? "Utilisateurs illimités"
          : "Unlimited users",
        language === 'fr' 
          ? "Support premium 24/7"
          : "Premium 24/7 support",
        language === 'fr' 
          ? "SLA personnalisé"
          : "Custom SLA",
        language === 'fr' 
          ? "Tous les secteurs avec configurations personnalisées"
          : "All sectors with custom configurations",
      ],
      cta: language === 'fr' ? "Planifier une consultation" : "Schedule Consultation",
    },
  ];

  return (
    <section className="py-16 bg-background">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">{t(language, 'pricing.title')}</h2>
          <p className="text-xl text-foreground/70 max-w-2xl mx-auto">
            {language === 'fr' 
              ? "Choisissez le plan qui correspond à vos besoins. Tous les plans incluent un essai gratuit de 14 jours."
              : "Choose the plan that fits your needs. All plans include a 14-day free trial."}
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {pricingTiers.map((tier, index) => {
            const isHighlighted = tier.highlighted;
            const borderClass = isHighlighted
              ? "border-accent border-2 shadow-lg shadow-accent/20 scale-105"
              : "border-border hover:border-accent/50";

            return (
              <Card key={index} className={`relative flex flex-col p-8 transition-all duration-300 ${borderClass}`}>
                {tier.badge && (
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-accent text-accent-foreground">
                    {tier.badge}
                  </Badge>
                )}

                <div className="mb-6">
                  <h3 className="text-2xl font-bold mb-2">{tier.name}</h3>
                  <p className="text-foreground/70 text-sm mb-4">{tier.tagline}</p>
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-bold text-accent">{tier.price}</span>
                    {tier.period && <span className="text-foreground/60">{tier.period}</span>}
                  </div>
                </div>

                <CheckoutButton
                  planId={tier.name.toLowerCase() as "starter" | "professional" | "enterprise"}
                  label={tier.cta}
                  className={`w-full mb-6 font-semibold ${
                    isHighlighted
                      ? "bg-accent hover:bg-accent/90 text-accent-foreground"
                      : "bg-card border border-accent text-accent hover:bg-accent/10"
                  }`}
                />

                <div className="flex-1">
                  <p className="text-sm font-semibold text-foreground/70 mb-4">
                    {language === 'fr' ? "Inclus :" : "Included:"}
                  </p>
                  <ul className="space-y-3">
                    {tier.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex gap-3 text-sm">
                        <Check className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                        <span className="text-foreground/80">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Comparison Table */}
        <div className="mt-16 overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-4 px-4 font-semibold">
                  {language === 'fr' ? "Fonctionnalité" : "Feature"}
                </th>
                <th className="text-center py-4 px-4 font-semibold">{t(language, 'pricing.starter')}</th>
                <th className="text-center py-4 px-4 font-semibold">{t(language, 'pricing.professional')}</th>
                <th className="text-center py-4 px-4 font-semibold">{t(language, 'pricing.enterprise')}</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-border/50">
                <td className="py-3 px-4">
                  {language === 'fr' ? "Heures IA par mois" : "AI hours per month"}
                </td>
                <td className="text-center">2</td>
                <td className="text-center">6</td>
                <td className="text-center">{language === 'fr' ? "Illimité" : "Unlimited"}</td>
              </tr>
              <tr className="border-b border-border/50">
                <td className="py-3 px-4">
                  {language === 'fr' ? "Leads qualifiés/mois" : "Qualified leads/month"}
                </td>
                <td className="text-center">6-10</td>
                <td className="text-center">20-30</td>
                <td className="text-center">{language === 'fr' ? "Illimité" : "Unlimited"}</td>
              </tr>
              <tr className="border-b border-border/50">
                <td className="py-3 px-4">
                  {language === 'fr' ? "Utilisateurs" : "Users"}
                </td>
                <td className="text-center">1</td>
                <td className="text-center">3</td>
                <td className="text-center">{language === 'fr' ? "Illimité" : "Unlimited"}</td>
              </tr>
              <tr className="border-b border-border/50">
                <td className="py-3 px-4">
                  {language === 'fr' ? "Déploiement sur site" : "On-premise deployment"}
                </td>
                <td className="text-center">-</td>
                <td className="text-center">-</td>
                <td className="text-center">
                  <Check className="w-5 h-5 text-accent mx-auto" />
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4">
                  {language === 'fr' ? "Support 24/7" : "24/7 Support"}
                </td>
                <td className="text-center">-</td>
                <td className="text-center">-</td>
                <td className="text-center">
                  <Check className="w-5 h-5 text-accent mx-auto" />
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
