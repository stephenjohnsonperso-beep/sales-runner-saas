import { useEffect, useState } from "react";
import { toast } from "sonner";

export interface Notification {
  id: string;
  type: "success" | "error" | "info" | "warning";
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
}

/**
 * Notification Center Hook
 * Manages notifications and displays them as toasts
 */
export function useNotificationCenter() {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const addNotification = (
    type: "success" | "error" | "info" | "warning",
    title: string,
    message: string
  ) => {
    const id = `notif-${Date.now()}`;
    const notification: Notification = {
      id,
      type,
      title,
      message,
      timestamp: new Date(),
      read: false,
    };

    // Add to notifications list
    setNotifications((prev) => [notification, ...prev]);

    // Show toast
    switch (type) {
      case "success":
        toast.success(title, { description: message });
        break;
      case "error":
        toast.error(title, { description: message });
        break;
      case "warning":
        toast.warning(title, { description: message });
        break;
      case "info":
      default:
        toast.info(title, { description: message });
        break;
    }

    return id;
  };

  const markAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((notif) =>
        notif.id === id ? { ...notif, read: true } : notif
      )
    );
  };

  const clearNotification = (id: string) => {
    setNotifications((prev) => prev.filter((notif) => notif.id !== id));
  };

  const clearAll = () => {
    setNotifications([]);
  };

  const getUnreadCount = () => {
    return notifications.filter((notif) => !notif.read).length;
  };

  return {
    notifications,
    addNotification,
    markAsRead,
    clearNotification,
    clearAll,
    getUnreadCount,
  };
}

/**
 * Notification types for common scenarios
 */
export const notificationTypes = {
  reportGenerated: (companyName: string) => ({
    type: "success" as const,
    title: "Rapport généré",
    message: `Le rapport pour ${companyName} a été généré avec succès et envoyé par email.`,
  }),

  reportError: (error: string) => ({
    type: "error" as const,
    title: "Erreur de génération",
    message: `Impossible de générer le rapport: ${error}`,
  }),

  subscriptionUpdated: (plan: string) => ({
    type: "success" as const,
    title: "Abonnement mis à jour",
    message: `Votre abonnement au plan ${plan} est maintenant actif.`,
  }),

  paymentFailed: () => ({
    type: "error" as const,
    title: "Erreur de paiement",
    message: "Le paiement n'a pas pu être traité. Veuillez réessayer.",
  }),

  profileUpdated: () => ({
    type: "success" as const,
    title: "Profil mis à jour",
    message: "Vos informations ont été mises à jour avec succès.",
  }),

  limitReached: () => ({
    type: "warning" as const,
    title: "Limite atteinte",
    message: "Vous avez atteint votre limite de rapports gratuits ce mois-ci.",
  }),
};
