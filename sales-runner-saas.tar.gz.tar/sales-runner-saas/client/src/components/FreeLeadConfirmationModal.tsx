import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Mail, Clock } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { t } from "@/lib/i18n";

interface FreeLeadConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  email: string;
  companyName: string;
}

export function FreeLeadConfirmationModal({
  isOpen,
  onClose,
  email,
  companyName,
}: FreeLeadConfirmationModalProps) {
  const { language } = useLanguage();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-accent/20 rounded-full flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8 text-accent" />
            </div>
          </div>
          <DialogTitle className="text-center text-2xl">{t(language, 'confirmationModal.title')}</DialogTitle>
          <DialogDescription className="text-center mt-2">
            {t(language, 'confirmationModal.subtitle')}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="bg-card/50 rounded-lg p-4 space-y-3">
            <div className="flex items-start gap-3">
              <Mail className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-foreground">{t(language, 'confirmationModal.confirmationEmail')}</p>
                <p className="text-sm text-foreground/70 break-all">{email}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Clock className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-foreground">{t(language, 'confirmationModal.deliveryTime')}</p>
                <p className="text-sm text-foreground/70">{t(language, 'confirmationModal.deliveryMinutes')}</p>
              </div>
            </div>
          </div>

          <div className="bg-accent/10 rounded-lg p-4 border border-accent/20">
            <p className="text-sm text-foreground/80">
              <strong>{t(language, 'confirmationModal.company')}:</strong> {companyName}
            </p>
          </div>

          <div className="bg-blue-500/10 rounded-lg p-4 border border-blue-500/20">
            <p className="text-sm text-blue-600 dark:text-blue-400">
              {t(language, 'confirmationModal.checkSpam')}
            </p>
          </div>
        </div>

        <div className="flex gap-3">
          <Button
            onClick={onClose}
            className="flex-1 bg-accent hover:bg-accent/90 text-accent-foreground"
          >
            {t(language, 'confirmationModal.close')}
          </Button>
        </div>

        <p className="text-xs text-foreground/60 text-center">
          {t(language, 'confirmationModal.closeMessage')} {email}
        </p>
      </DialogContent>
    </Dialog>
  );
}
