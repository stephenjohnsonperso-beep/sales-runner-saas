import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { AlertTriangle } from "lucide-react";
import { FreeLeadConfirmationModal } from "./FreeLeadConfirmationModal";
import { useLanguage } from "@/contexts/LanguageContext";
import { t } from "@/lib/i18n";

const formSchema = z.object({
  companyName: z.string().min(1, "Le nom de l'entreprise est requis"),
  contactName: z.string().min(1, "Votre nom est requis"),
  email: z.string().email("Email invalide"),
  idealCustomer: z.string().optional(),
});

type FormData = z.infer<typeof formSchema>;

export function FreeLeadForm() {
  const { language } = useLanguage();
  const [submitted, setSubmitted] = useState(false);
  const [canUseFreeReport, setCanUseFreeReport] = useState(true);
  const [limitMessage, setLimitMessage] = useState("");
  const [submittedEmail, setSubmittedEmail] = useState("");
  const [submittedCompany, setSubmittedCompany] = useState("");
  
  const submitMutation = trpc.freeLeads.submit.useMutation();
  const checkLimitQuery = trpc.freeLeads.checkLimit.useQuery(
    { email: "" },
    { enabled: false }
  );

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      companyName: "",
      contactName: "",
      email: "",
      idealCustomer: "",
    },
  });

  // Check limit when email changes
  const emailValue = form.watch("email");
  useEffect(() => {
    if (emailValue && emailValue.includes("@")) {
      checkLimitQuery.refetch().then((result) => {
        if (result.data) {
          setCanUseFreeReport(result.data.canUse);
          if (!result.data.canUse) {
            if (result.data.emailUsed) {
              setLimitMessage(t(language, 'freeLeadForm.limitReachedEmail'));
            } else {
              setLimitMessage(t(language, 'freeLeadForm.limitReachedMonth'));
            }
          } else {
            setLimitMessage("");
          }
        }
      });
    }
  }, [emailValue, checkLimitQuery, language]);

  const onSubmit = async (data: FormData) => {
    if (!canUseFreeReport) {
      toast.error(limitMessage || t(language, 'freeLeadForm.limitReached'));
      return;
    }

    try {
      await submitMutation.mutateAsync(data);
      setSubmitted(true);
      setSubmittedEmail(data.email);
      setSubmittedCompany(data.companyName);
      form.reset();
    } catch (error: any) {
      const errorMessage = error?.message || "Une erreur est survenue. Veuillez réessayer.";
      toast.error(errorMessage);
    }
  };

  if (submitted) {
    return (
      <FreeLeadConfirmationModal
        isOpen={submitted}
        onClose={() => setSubmitted(false)}
        email={submittedEmail}
        companyName={submittedCompany}
      />
    );
  }

  return (
    <Card className="p-8 bg-card border-border">
      <div className="mb-6">
        <h3 className="text-2xl font-bold mb-2">{t(language, 'freeLeadForm.title')}</h3>
        <p className="text-foreground/70">
          {t(language, 'freeLeadForm.subtitle')}
        </p>
      </div>

      {!canUseFreeReport && (
        <div className="mb-6 p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg flex gap-3">
          <AlertTriangle className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
          <div className="text-sm">
            <p className="font-semibold text-yellow-600 mb-1">{t(language, 'freeLeadForm.limitReached')}</p>
            <p className="text-yellow-600/80">{limitMessage}</p>
            <p className="text-yellow-600/70 mt-2">
              {t(language, 'freeLeadForm.subscribe')}
            </p>
          </div>
        </div>
      )}

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="companyName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t(language, 'freeLeadForm.companyName')}</FormLabel>
                <FormControl>
                  <Input placeholder={t(language, 'freeLeadForm.companyNamePlaceholder')} {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="contactName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t(language, 'freeLeadForm.contactName')}</FormLabel>
                <FormControl>
                  <Input placeholder={t(language, 'freeLeadForm.contactNamePlaceholder')} {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t(language, 'freeLeadForm.email')}</FormLabel>
                <FormControl>
                  <Input type="email" placeholder={t(language, 'freeLeadForm.emailPlaceholder')} {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="idealCustomer"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t(language, 'freeLeadForm.idealCustomer')}</FormLabel>
                <FormControl>
                  <Input
                    placeholder={t(language, 'freeLeadForm.idealCustomerPlaceholder')}
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="pt-2">
            <p className="text-xs text-foreground/60 mb-4">
              {t(language, 'freeLeadForm.privacy')}
            </p>
            <Button
              type="submit"
              className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold"
              disabled={submitMutation.isPending || !canUseFreeReport}
            >
              {submitMutation.isPending ? t(language, 'freeLeadForm.submitting') : t(language, 'freeLeadForm.submit')}
            </Button>
          </div>
        </form>
      </Form>
    </Card>
  );
}
