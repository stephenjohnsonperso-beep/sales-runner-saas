import { useContext } from 'react';
import { LanguageContext } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

export function LanguageToggle() {
  const context = useContext(LanguageContext);
  
  if (!context) {
    return null;
  }
  
  const { language, setLanguage } = context;

  return (
    <div className="flex items-center gap-1 bg-muted/50 rounded-lg p-1">
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setLanguage('fr')}
        className={cn(
          'px-3 py-1 text-sm font-medium transition-colors',
          language === 'fr'
            ? 'bg-background text-foreground shadow-sm'
            : 'text-muted-foreground hover:text-foreground'
        )}
      >
        FR
      </Button>
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setLanguage('en')}
        className={cn(
          'px-3 py-1 text-sm font-medium transition-colors',
          language === 'en'
            ? 'bg-background text-foreground shadow-sm'
            : 'text-muted-foreground hover:text-foreground'
        )}
      >
        EN
      </Button>
    </div>
  );
}
