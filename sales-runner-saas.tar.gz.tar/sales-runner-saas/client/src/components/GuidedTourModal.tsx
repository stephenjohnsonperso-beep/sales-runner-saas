import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ChevronRight, ChevronLeft, X } from "lucide-react";

interface GuidedTourModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function GuidedTourModal({ isOpen, onClose }: GuidedTourModalProps) {
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    {
      title: "Bienvenue sur Sales Runner",
      description: "Découvrez comment notre plateforme IA révolutionne la génération de leads pour le secteur industriel.",
      content: "Nous utilisons l'intelligence artificielle pour identifier et analyser les prospects qualifiés spécifiquement pour votre secteur d'activité.",
    },
    {
      title: "Étape 1 : Fournissez votre site web",
      description: "Commencez par nous donner l'adresse de votre site web ou quelques informations sur votre entreprise.",
      content: "Notre IA analyse votre profil commercial pour comprendre vos besoins spécifiques et identifier les prospects idéaux.",
    },
    {
      title: "Étape 2 : Analyse IA approfondie",
      description: "Notre système d'IA trouve et analyse les prospects idéaux pour votre offre.",
      content: "Nous parcourons des milliers de sources pour identifier les entreprises qui correspondent parfaitement à votre profil client idéal.",
    },
    {
      title: "Étape 3 : Rapports détaillés",
      description: "Recevez des rapports complets avec stratégies de prospection personnalisées.",
      content: "Chaque rapport contient des informations sur les décideurs, l'analyse concurrentielle, et des stratégies d'approche prêtes à l'emploi.",
    },
    {
      title: "Résultats rapides et fiables",
      description: "Obtenez vos premiers rapports en 12-14 minutes, avec une qualité garantie.",
      content: "Notre plateforme traite votre demande en temps réel et vous livre des insights actionnables immédiatement.",
    },
  ];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{steps[currentStep].title}</DialogTitle>
        </DialogHeader>

        <div className="py-6">
          <div className="mb-6">
            <p className="text-lg font-semibold text-accent mb-3">
              {steps[currentStep].description}
            </p>
            <p className="text-foreground/80 leading-relaxed">
              {steps[currentStep].content}
            </p>
          </div>

          {/* Progress indicator */}
          <div className="flex gap-2 mb-6">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`h-2 flex-1 rounded-full transition-colors ${
                  index === currentStep
                    ? "bg-accent"
                    : index < currentStep
                      ? "bg-accent/50"
                      : "bg-muted"
                }`}
              />
            ))}
          </div>

          {/* Navigation buttons */}
          <div className="flex justify-between items-center">
            <Button
              variant="outline"
              onClick={handlePrev}
              disabled={currentStep === 0}
              className="gap-2"
            >
              <ChevronLeft className="w-4 h-4" />
              Précédent
            </Button>

            <span className="text-sm text-muted-foreground">
              {currentStep + 1} / {steps.length}
            </span>

            {currentStep === steps.length - 1 ? (
              <Button onClick={onClose} className="gap-2">
                Terminer
                <X className="w-4 h-4" />
              </Button>
            ) : (
              <Button onClick={handleNext} className="gap-2">
                Suivant
                <ChevronRight className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
