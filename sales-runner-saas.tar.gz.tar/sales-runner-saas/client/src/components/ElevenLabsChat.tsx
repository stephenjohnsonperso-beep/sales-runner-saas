import { useEffect } from "react";

interface ElevenLabsChatProps {
  agentId?: string;
  className?: string;
}

/**
 * ElevenLabsChat Component
 * 
 * Integrates the 11 Labs Conversational AI widget into your application.
 * The widget appears as a floating button in the bottom-right corner.
 * 
 * Usage:
 * <ElevenLabsChat agentId="your-agent-id" />
 * 
 * To get your agent ID:
 * 1. Go to https://elevenlabs.io/app/conversational-ai
 * 2. Create or select an agent
 * 3. Copy the Agent ID from the agent details
 * 4. Set it as an environment variable: VITE_ELEVENLABS_AGENT_ID
 */
export function ElevenLabsChat({ agentId, className }: ElevenLabsChatProps) {
  useEffect(() => {
    // Get agent ID from props or environment variable
    const finalAgentId = agentId || import.meta.env.VITE_ELEVENLABS_AGENT_ID;

    if (!finalAgentId) {
      console.warn(
        "[11 Labs Chat] Agent ID not provided. Set VITE_ELEVENLABS_AGENT_ID environment variable or pass agentId prop."
      );
      return;
    }

    // Load the 11 Labs script
    const script = document.createElement("script");
    script.src = "https://elevenlabs.io/convai-widget/index.js";
    script.async = true;
    script.onload = () => {
      // Initialize the widget after script loads
      if (window.ElevenLabsConvAI) {
        window.ElevenLabsConvAI.setAgentId(finalAgentId);
      }
    };
    document.head.appendChild(script);

    return () => {
      // Cleanup: remove script if component unmounts
      if (script.parentNode) {
        script.parentNode.removeChild(script);
      }
    };
  }, [agentId]);

  return (
    <div
      id="convai-widget-container"
      className={className}
      style={{
        position: "fixed",
        bottom: "20px",
        right: "20px",
        zIndex: 9999,
      }}
    />
  );
}

// Extend window type to include ElevenLabsConvAI
declare global {
  interface Window {
    ElevenLabsConvAI?: {
      setAgentId: (agentId: string) => void;
    };
  }
}
