import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";

interface CheckoutButtonProps {
  planId: "starter" | "professional" | "enterprise";
  label?: string;
  className?: string;
}

export function CheckoutButton({ planId, label = "Choisir ce plan", className }: CheckoutButtonProps) {
  const { isAuthenticated } = useAuth();
  const checkoutMutation = trpc.checkout.createSession.useMutation();

  const handleCheckout = async () => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl();
      return;
    }

    try {
      const result = await checkoutMutation.mutateAsync({ planId });
      if (result.checkoutUrl) {
        window.open(result.checkoutUrl, "_blank");
        toast.success("Redirection vers le paiement...");
      }
    } catch (error) {
      toast.error("Erreur lors de la création de la session de paiement");
      console.error(error);
    }
  };

  return (
    <Button
      onClick={handleCheckout}
      disabled={checkoutMutation.isPending}
      className={className}
    >
      {checkoutMutation.isPending ? "Chargement..." : label}
    </Button>
  );
}
