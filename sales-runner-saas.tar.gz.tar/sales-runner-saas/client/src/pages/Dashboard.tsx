import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ElevenLabsChat } from "@/components/ElevenLabsChat";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { FileText, Plus, LogOut, Download, AlertCircle } from "lucide-react";
import { useEffect } from "react";

export default function Dashboard() {
  const { user, isAuthenticated, logout } = useAuth();
  const [, navigate] = useLocation();
  const reportsQuery = trpc.reports.list.useQuery(undefined, { enabled: isAuthenticated });
  const generatedReportsQuery = trpc.generatedReports.list.useQuery(undefined, { enabled: isAuthenticated });
  const subscriptionQuery = trpc.subscriptions.current.useQuery(undefined, { enabled: isAuthenticated });

  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/");
    }
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b border-border/50 bg-card/50">
        <div className="container py-6 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Tableau de bord</h1>
            <p className="text-foreground/70 mt-1">Bienvenue, {user?.name || "utilisateur"}</p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => navigate("/profile")}
              className="gap-2"
            >
              Profil
            </Button>
            <Button
              variant="outline"
              onClick={() => logout()}
              className="gap-2"
            >
              <LogOut className="w-4 h-4" />
              Déconnexion
            </Button>
          </div>
        </div>
      </div>

      <div className="container py-8">
        {/* Subscription Info */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="p-6">
            <h3 className="text-sm font-semibold text-foreground/70 mb-2">Abonnement actif</h3>
            <p className="text-2xl font-bold text-accent">
              {subscriptionQuery.data ? "Actif" : "Aucun"}
            </p>
            <p className="text-xs text-foreground/60 mt-2">
              {subscriptionQuery.data?.status === "active" ? "Votre abonnement est actif" : "Pas d'abonnement"}
            </p>
          </Card>

          <Card className="p-6">
            <h3 className="text-sm font-semibold text-foreground/70 mb-2">Rapports générés</h3>
            <p className="text-2xl font-bold text-accent">
              {generatedReportsQuery.data?.length || 0}
            </p>
            <p className="text-xs text-foreground/60 mt-2">
              Rapports d'intelligence B2B
            </p>
          </Card>

          <Card className="p-6">
            <h3 className="text-sm font-semibold text-foreground/70 mb-2">Statut du compte</h3>
            <p className="text-2xl font-bold text-accent">
              {user?.role === "admin" ? "Admin" : "Utilisateur"}
            </p>
            <p className="text-xs text-foreground/60 mt-2">
              Rôle du compte
            </p>
          </Card>
        </div>

        {/* Test Section */}
        <div className="mb-8 p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
          <p className="text-sm text-blue-700 mb-3">
            <strong>Mode développement :</strong> Testez l'intégration Tasklet AI en déclenchant manuellement une génération de rapports.
          </p>
          <Button
            variant="outline"
            onClick={() => navigate("/test/tasklet")}
            className="gap-2"
          >
            Accéder au test Tasklet AI
          </Button>
        </div>

        {/* Generated Reports Section */}
        <div className="mb-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Mes rapports d'intelligence B2B</h2>
          </div>

          {generatedReportsQuery.isLoading ? (
            <Card className="p-8 text-center">
              <p className="text-foreground/70">Chargement des rapports...</p>
            </Card>
          ) : generatedReportsQuery.data && generatedReportsQuery.data.length > 0 ? (
            <div className="grid gap-4">
              {generatedReportsQuery.data.map((report) => (
                <Card key={report.id} className="p-6 border-border hover:border-accent/50 transition">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4 flex-1">
                      <div className="w-10 h-10 bg-accent/20 rounded-lg flex items-center justify-center flex-shrink-0">
                        <FileText className="w-5 h-5 text-accent" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-bold">{report.targetCompany}</h3>
                        <p className="text-sm text-foreground/70 mt-1">
                          Industrie: {report.targetIndustry || "Non spécifiée"}
                        </p>
                        <p className="text-xs text-foreground/60 mt-1">
                          Rapport #{report.reportNumber} • Créé le {new Date(report.createdAt).toLocaleDateString("fr-FR")}
                        </p>
                      </div>
                    </div>
                    <div className="text-right flex flex-col items-end gap-3">
                      <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                        report.status === "sent"
                          ? "bg-accent/20 text-accent"
                          : report.status === "generated"
                            ? "bg-blue-500/20 text-blue-400"
                            : "bg-yellow-500/20 text-yellow-400"
                      }`}>
                        {report.status === "sent" ? "Envoyé" : report.status === "generated" ? "Généré" : "En attente"}
                      </span>
                      {report.pdfUrl && (
                        <a href={report.pdfUrl} target="_blank" rel="noopener noreferrer">
                          <Button size="sm" variant="outline" className="gap-2">
                            <Download className="w-4 h-4" />
                            Télécharger
                          </Button>
                        </a>
                      )}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="p-8 text-center">
              <FileText className="w-12 h-12 text-foreground/30 mx-auto mb-4" />
              <p className="text-foreground/70">Aucun rapport généré pour le moment</p>
              <p className="text-sm text-foreground/60 mt-2">
                Les rapports d'intelligence B2B apparaîtront ici une fois générés
              </p>
            </Card>
          )}
        </div>

        {/* Lead Reports Section */}
        <div>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Mes rapports de leads</h2>
            <Button className="bg-accent hover:bg-accent/90 text-accent-foreground gap-2">
              <Plus className="w-4 h-4" />
              Nouveau rapport
            </Button>
          </div>

          {reportsQuery.isLoading ? (
            <Card className="p-8 text-center">
              <p className="text-foreground/70">Chargement des rapports...</p>
            </Card>
          ) : reportsQuery.data && reportsQuery.data.length > 0 ? (
            <div className="grid gap-4">
              {reportsQuery.data.map((report) => (
                <Card key={report.id} className="p-6 border-border hover:border-accent/50 transition">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4 flex-1">
                      <div className="w-10 h-10 bg-accent/20 rounded-lg flex items-center justify-center flex-shrink-0">
                        <FileText className="w-5 h-5 text-accent" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-bold">{report.companyName}</h3>
                        <p className="text-sm text-foreground/70 mt-1">
                          Contact: {report.contactName}
                        </p>
                        <p className="text-xs text-foreground/60 mt-1">
                          Créé le {new Date(report.createdAt).toLocaleDateString("fr-FR")}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                        report.status === "sent"
                          ? "bg-accent/20 text-accent"
                          : report.status === "generated"
                            ? "bg-blue-500/20 text-blue-400"
                            : "bg-yellow-500/20 text-yellow-400"
                      }`}>
                        {report.status === "sent" ? "Envoyé" : report.status === "generated" ? "Généré" : "En attente"}
                      </span>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="p-8 text-center">
              <FileText className="w-12 h-12 text-foreground/30 mx-auto mb-4" />
              <p className="text-foreground/70">Aucun rapport pour le moment</p>
              <p className="text-sm text-foreground/60 mt-2">
                Créez votre premier rapport de leads pour commencer
              </p>
              <Button className="mt-4 bg-accent hover:bg-accent/90 text-accent-foreground gap-2">
                <Plus className="w-4 h-4" />
                Créer un rapport
              </Button>
            </Card>
          )}
        </div>
      </div>

      {/* 11 Labs Chat Widget */}
      <ElevenLabsChat />
    </div>
  );
}
