import { useState } from "react";
import { Button } from "@/components/ui/button";
import { GuidedTourModal } from "@/components/GuidedTourModal";
import { FreeLeadForm } from "@/components/FreeLeadForm";
import { PricingSection } from "@/components/PricingSection";
import { ElevenLabsChat } from "@/components/ElevenLabsChat";
import { LanguageToggle } from "@/components/LanguageToggle";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { t } from "@/lib/i18n";
import { ArrowRight, Shield, Zap, TrendingUp, CheckCircle2, Lock, AlertTriangle } from "lucide-react";

export default function Home() {
  const [showTourModal, setShowTourModal] = useState(false);
  const { isAuthenticated } = useAuth();
  const { language } = useLanguage();

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur-sm">
        <div className="container flex justify-between items-center py-4">
          <div className="flex items-center gap-2">
            <img src="/logo.png" alt="Sales Runner" className="w-10 h-10 object-contain" />
            <span className="font-bold text-lg">Sales Runner</span>
          </div>
          <div className="flex items-center gap-6">
            <a href="#how-it-works" className="text-foreground/70 hover:text-foreground transition">
              {t(language, 'nav.howItWorks')}
            </a>
            <a href="#pricing" className="text-foreground/70 hover:text-foreground transition">
              {t(language, 'nav.pricing')}
            </a>
            <LanguageToggle />
            {isAuthenticated ? (
              <a href="/dashboard" className="text-foreground/70 hover:text-foreground transition">
                {t(language, 'nav.dashboard')}
              </a>
            ) : (
              <Button
                onClick={() => window.location.href = getLoginUrl()}
                variant="outline"
                size="sm"
              >
                {t(language, 'nav.login')}
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 border-b border-border bg-gradient-to-b from-background via-background to-background">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              {t(language, 'hero.title')}{" "}
              <span className="text-accent">{t(language, 'hero.titleHighlight')}</span>
            </h1>
            <p className="text-xl text-foreground/70 mb-8 leading-relaxed">
              {t(language, 'hero.subtitle')}
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <Button
                size="lg"
                className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold gap-2"
                onClick={() => {
                  const element = document.getElementById('free-lead-form');
                  if (element) {
                    element.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
              >
                {t(language, 'hero.cta')}
                <ArrowRight className="w-5 h-5" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => setShowTourModal(true)}
                className="border-accent text-accent hover:bg-accent/10"
              >
                {t(language, 'hero.guidedTour')}
              </Button>
            </div>

            <div className="flex flex-col sm:flex-row justify-center gap-6 text-sm text-foreground/70">
              <div className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-accent" />
                <span>{t(language, 'hero.aiPowered')}</span>
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-accent" />
                <span>{t(language, 'hero.industryIntel')}</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Value Proposition */}
      <section className="py-16 border-b border-border bg-background">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">{t(language, 'valueProps.title')}</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="p-6 rounded-lg bg-white border border-border shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-accent" />
              </div>
              <h3 className="text-xl font-bold mb-2">{t(language, 'valueProps.leads.title')}</h3>
              <p className="text-foreground/70">
                {t(language, 'valueProps.leads.desc')}
              </p>
            </div>

            <div className="p-6 rounded-lg bg-white border border-border shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-accent" />
              </div>
              <h3 className="text-xl font-bold mb-2">{t(language, 'valueProps.intelligence.title')}</h3>
              <p className="text-foreground/70">
                {t(language, 'valueProps.intelligence.desc')}
              </p>
            </div>

            <div className="p-6 rounded-lg bg-white border border-border shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                <ArrowRight className="w-6 h-6 text-accent" />
              </div>
              <h3 className="text-xl font-bold mb-2">{t(language, 'valueProps.speed.title')}</h3>
              <p className="text-foreground/70">
                {t(language, 'valueProps.speed.desc')}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-16 border-b border-border bg-gradient-to-b from-background/50 to-background">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">{t(language, 'howItWorks.title')}</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="text-center">
              <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-accent">1</span>
              </div>
              <h3 className="text-xl font-bold mb-2">{t(language, 'howItWorks.step1')}</h3>
              <p className="text-foreground/70">
                {t(language, 'howItWorks.step1Desc')}
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-accent">2</span>
              </div>
              <h3 className="text-xl font-bold mb-2">{t(language, 'howItWorks.step2')}</h3>
              <p className="text-foreground/70">
                {t(language, 'howItWorks.step2Desc')}
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-accent">3</span>
              </div>
              <h3 className="text-xl font-bold mb-2">{t(language, 'howItWorks.step3')}</h3>
              <p className="text-foreground/70">
                {t(language, 'howItWorks.step3Desc')}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Free Lead Form */}
      <section className="py-16 border-b border-border" id="free-lead-form">
        <div className="container max-w-2xl">
          <FreeLeadForm />
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing">
        <PricingSection />
      </section>

      {/* Trust & Security */}
      <section className="py-16 border-b border-border bg-background">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">{t(language, 'trust.title')}</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="text-center">
              <Lock className="w-12 h-12 text-accent mx-auto mb-4" />
              <h3 className="text-lg font-bold mb-2">{t(language, 'trust.payments')}</h3>
              <p className="text-foreground/70 text-sm">
                {t(language, 'trust.paymentsDesc')}
              </p>
            </div>

            <div className="text-center">
              <Shield className="w-12 h-12 text-accent mx-auto mb-4" />
              <h3 className="text-lg font-bold mb-2">{t(language, 'trust.transparency')}</h3>
              <p className="text-foreground/70 text-sm">
                {t(language, 'trust.transparencyDesc')}
              </p>
            </div>

            <div className="text-center">
              <CheckCircle2 className="w-12 h-12 text-accent mx-auto mb-4" />
              <h3 className="text-lg font-bold mb-2">{t(language, 'trust.privacy')}</h3>
              <p className="text-foreground/70 text-sm">
                {t(language, 'trust.privacyDesc')}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Legal Disclaimer */}
      <section className="py-16 bg-background">
        <div className="container max-w-4xl">
          <div className="warning-box">
            <div className="flex gap-3 mb-4">
              <AlertTriangle className="w-6 h-6 text-yellow-600 dark:text-yellow-500 flex-shrink-0 mt-0.5" />
              <h3 className="text-yellow-800 dark:text-yellow-200 font-bold text-lg">{t(language, 'disclaimer.title')}</h3>
            </div>

            <div className="space-y-3 text-yellow-700 dark:text-yellow-100 text-sm leading-relaxed">
              <p>
                <strong>{t(language, 'disclaimer.aiGenerated')}</strong> {t(language, 'disclaimer.aiGeneratedText')}
              </p>

              <p>
                <strong>{t(language, 'disclaimer.noApproval')}</strong> {t(language, 'disclaimer.noApprovalText')}
              </p>

              <p>
                <strong>{t(language, 'disclaimer.userResponsibility')}</strong> {t(language, 'disclaimer.userResponsibilityText')}
              </p>

              <p>
                <strong>{t(language, 'disclaimer.noLiability')}</strong> {t(language, 'disclaimer.noLiabilityText')}
              </p>

              <p>
                <strong>{t(language, 'disclaimer.compliance')}</strong> {t(language, 'disclaimer.complianceText')}
              </p>

              <p>
                <strong>{t(language, 'disclaimer.ip')}</strong> {t(language, 'disclaimer.ipText')}
              </p>

              <p>
                <strong>{t(language, 'disclaimer.noGuarantee')}</strong> {t(language, 'disclaimer.noGuaranteeText')}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-background py-8">
        <div className="container text-center text-foreground/70 text-sm">
          <p>{t(language, 'footer.copyright')}</p>
        </div>
      </footer>

      {/* Modals */}
      {showTourModal && <GuidedTourModal onClose={() => setShowTourModal(false)} />}
      <ElevenLabsChat />
    </div>
  );
}
