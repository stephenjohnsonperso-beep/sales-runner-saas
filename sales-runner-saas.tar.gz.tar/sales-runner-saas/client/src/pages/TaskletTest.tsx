import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Loader2, CheckCircle, AlertCircle } from "lucide-react";
import { useLocation } from "wouter";

export default function TaskletTest() {
  const { user, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    companyName: "",
    email: "",
    valueProposition: "",
    targetIndustries: "Manufacturing,Industrial",
  });
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const triggerMutation = trpc.generatedReports.trigger.useMutation();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleTriggerGeneration = async () => {
    if (!formData.companyName.trim() || !formData.email.trim() || !formData.valueProposition.trim()) {
      toast.error("Veuillez remplir tous les champs");
      return;
    }

    setIsLoading(true);
    try {
      const industries = formData.targetIndustries
        .split(",")
        .map((i) => i.trim())
        .filter((i) => i.length > 0);

      const response = await triggerMutation.mutateAsync({
        companyName: formData.companyName,
        email: formData.email,
        valueProposition: formData.valueProposition,
        targetIndustries: industries,
      });

      setResult(response);
      toast.success("Génération de rapports déclenchée avec succès");
      setIsLoading(false);
    } catch (error: any) {
      toast.error(error.message || "Erreur lors du déclenchement de la génération");
      setIsLoading(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="animate-spin w-8 h-8 text-primary" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Accès non autorisé</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Vous devez être connecté pour accéder à cette page.
            </p>
            <Button onClick={() => setLocation("/")} className="w-full">
              Retour à l'accueil
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container max-w-2xl py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/dashboard")}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">Test Tasklet AI</h1>
            <p className="text-muted-foreground">Déclenchez manuellement la génération de rapports</p>
          </div>
        </div>

        {/* Test Form */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Paramètres de génération</CardTitle>
            <CardDescription>
              Remplissez les informations pour déclencher la génération de rapports via Tasklet AI
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="companyName">Nom de l'entreprise</Label>
              <Input
                id="companyName"
                name="companyName"
                value={formData.companyName}
                onChange={handleInputChange}
                placeholder="Ex: Acme Corporation"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Adresse email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleInputChange}
                placeholder="contact@acme.com"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="valueProposition">Proposition de valeur</Label>
              <textarea
                id="valueProposition"
                name="valueProposition"
                value={formData.valueProposition}
                onChange={handleInputChange}
                placeholder="Décrivez ce que votre entreprise vend..."
                className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                rows={4}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="targetIndustries">Industries cibles (séparées par des virgules)</Label>
              <Input
                id="targetIndustries"
                name="targetIndustries"
                value={formData.targetIndustries}
                onChange={handleInputChange}
                placeholder="Manufacturing, Industrial, Technology"
              />
            </div>

            <Button
              onClick={handleTriggerGeneration}
              disabled={isLoading}
              className="w-full"
            >
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Déclencher la génération
            </Button>
          </CardContent>
        </Card>

        {/* Result */}
        {result && (
          <Card className="border-green-500/50 bg-green-500/5">
            <CardHeader>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-500" />
                <CardTitle>Génération déclenchée avec succès</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground">ID de requête</p>
                <p className="text-sm font-mono bg-background p-2 rounded mt-1">{result.requestId}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Message</p>
                <p className="text-sm mt-1">{result.message}</p>
              </div>
              <div className="bg-blue-500/10 border border-blue-500/20 rounded p-3">
                <div className="flex gap-2">
                  <AlertCircle className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-blue-700">
                    Les rapports sont en cours de génération. Vous recevrez un email avec les PDFs une fois terminés.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Info Section */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>À propos du test</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-sm text-muted-foreground">
            <p>
              Cette page vous permet de tester manuellement l'intégration avec Tasklet AI. Lorsque vous déclenchez une génération :
            </p>
            <ul className="list-disc list-inside space-y-2">
              <li>Une requête est envoyée à Tasklet AI avec vos paramètres</li>
              <li>Tasklet AI génère 5 rapports d'intelligence B2B</li>
              <li>Les PDFs sont envoyés à votre adresse email via notre webhook</li>
              <li>Les rapports apparaissent dans votre tableau de bord</li>
            </ul>
            <p className="pt-2">
              <strong>Note :</strong> La génération peut prendre quelques minutes. Vérifiez votre email et votre tableau de bord.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
