import { describe, it, expect } from 'vitest';
import { translations, t } from './i18n';

describe('i18n translations', () => {
  it('should have both FR and EN translations', () => {
    expect(translations).toHaveProperty('fr');
    expect(translations).toHaveProperty('en');
  });

  it('should have navigation translations', () => {
    expect(translations.en.nav).toBeDefined();
    expect(translations.fr.nav).toBeDefined();
    expect(translations.en.nav.howItWorks).toBe('How It Works');
    expect(translations.fr.nav.howItWorks).toBe('Comment ça marche');
  });

  it('should have hero section translations', () => {
    expect(translations.en.hero).toBeDefined();
    expect(translations.fr.hero).toBeDefined();
    expect(translations.en.hero.title).toBe('AI-Powered Lead Generation for');
    expect(translations.fr.hero.title).toBe('Generation de leads IA pour les');
  });

  it('should have value proposition translations', () => {
    expect(translations.en.valueProps).toBeDefined();
    expect(translations.fr.valueProps).toBeDefined();
    expect(translations.en.valueProps.title).toBe('What We Offer');
    expect(translations.fr.valueProps.title).toBe('Ce que nous offrons');
  });

  it('should have pricing translations', () => {
    expect(translations.en.pricing).toBeDefined();
    expect(translations.fr.pricing).toBeDefined();
    expect(translations.en.pricing.starter).toBe('Starter');
    expect(translations.fr.pricing.starter).toBe('Starter');
  });

  it('should have free lead form translations', () => {
    expect(translations.en.freeLeadForm).toBeDefined();
    expect(translations.fr.freeLeadForm).toBeDefined();
    expect(translations.en.freeLeadForm.title).toBe('Get Your Free Report');
    expect(translations.fr.freeLeadForm.title).toBe('Obtenir votre rapport gratuit');
  });

  it('should have confirmation modal translations', () => {
    expect(translations.en.confirmationModal).toBeDefined();
    expect(translations.fr.confirmationModal).toBeDefined();
    expect(translations.en.confirmationModal.title).toBe('Request Received!');
    expect(translations.fr.confirmationModal.title).toBe('Demande de rapport confirmee');
  });

  it('should have trust section translations', () => {
    expect(translations.en.trust).toBeDefined();
    expect(translations.fr.trust).toBeDefined();
    expect(translations.en.trust.title).toBe('Trust and Security');
    expect(translations.fr.trust.title).toBe('Confiance et securite');
  });

  it('should have disclaimer translations', () => {
    expect(translations.en.disclaimer).toBeDefined();
    expect(translations.fr.disclaimer).toBeDefined();
    expect(translations.en.disclaimer.title).toBe('Important Legal Disclaimer');
    expect(translations.fr.disclaimer.title).toBe('Avis Juridique');
  });

  it('should have footer translations', () => {
    expect(translations.en.footer).toBeDefined();
    expect(translations.fr.footer).toBeDefined();
    expect(translations.en.footer.copyright).toContain('2026');
    expect(translations.fr.footer.copyright).toContain('2026');
  });

  it('should handle nested translation keys', () => {
    const enHeroTitle = t('en', 'hero.title');
    const frHeroTitle = t('fr', 'hero.title');
    expect(enHeroTitle).toBe('AI-Powered Lead Generation for');
    expect(frHeroTitle).toBe('Generation de leads IA pour les');
  });

  it('should return key if translation not found', () => {
    const result = t('en', 'nonexistent.key');
    expect(result).toBe('nonexistent.key');
  });

  it('should handle deeply nested keys', () => {
    const enLeadsTitle = t('en', 'valueProps.leads.title');
    const frLeadsTitle = t('fr', 'valueProps.leads.title');
    expect(enLeadsTitle).toBe('Qualified B2B Leads');
    expect(frLeadsTitle).toBe('Leads Qualifies');
  });
});
