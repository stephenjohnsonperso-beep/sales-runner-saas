export type Language = 'fr' | 'en';

export const translations = {
  fr: {
    // Navigation
    nav: {
      howItWorks: 'Comment ça marche',
      pricing: 'Tarification',
      dashboard: 'Tableau de bord',
      login: 'Connexion',
      logout: 'Déconnexion',
      profile: 'Profil',
    },
    // Hero Section
    hero: {
      title: 'Account Acquisition Intelligence pour les',
      titleHighlight: 'fabricants industriels',
      subtitle: 'Obtenez des leads B2B qualifiés avec des rapports d\'intelligence approfondie. Conçu spécifiquement pour les fabricants, distributeurs et fournisseurs d\'équipements industriels.',
      cta: 'Obtenir votre rapport gratuit',
      guidedTour: 'Visite guidée',
      aiPowered: 'Analyse alimentée par l\'IA',
      industryIntel: 'Intelligence spécifique à l\'industrie',
    },
    // Value Proposition
    valueProps: {
      title: 'Ce que nous offrons',
      leads: {
        title: 'Leads B2B qualifiés',
        desc: 'Rapports détaillés avec profils de décideurs clés et stratégies d\'approche.',
      },
      intelligence: {
        title: 'Intelligence approfondie',
        desc: 'Analyse BANT+ complète avec évaluation de la qualification des leads.',
      },
      speed: {
        title: 'Livraison rapide',
        desc: 'Rapports générés en 12-14 minutes avec insights actionnables.',
      },
    },
    // How It Works
    howItWorks: {
      title: 'Comment ça marche',
      step1: 'Fournissez votre site web',
      step1Desc: 'Donnez-nous votre adresse web ou quelques informations sur votre entreprise.',
      step2: 'Notre IA analyse',
      step2Desc: 'Notre système trouve et analyse les prospects idéaux pour votre offre.',
      step3: 'Recevez vos rapports',
      step3Desc: 'Rapports détaillés avec stratégies d\'approche en 12-14 minutes.',
    },
    // Free Lead Form
    freeLeadForm: {
      title: 'Obtenez votre rapport gratuit',
      subtitle: 'Expérimentez l\'intelligence IA de Sales Runner avec un rapport court-forme gratuit',
      companyName: 'Nom de votre entreprise',
      companyNamePlaceholder: 'Ex: Acme Manufacturing',
      contactName: 'Votre nom',
      contactNamePlaceholder: 'Ex: Jean Dupont',
      email: 'Email',
      emailPlaceholder: 'votre@email.com',
      idealCustomer: 'Votre client idéal (optionnel)',
      idealCustomerPlaceholder: 'Ex: Usines de transformation alimentaire',
      privacy: '✓ Vos informations sont sécurisées et ne seront jamais partagées. Aucune carte de crédit requise.',
      submit: 'Générer mon rapport gratuit',
      submitting: 'Génération en cours...',
      limitReached: 'Limite atteinte',
      limitReachedEmail: 'Vous avez déjà utilisé votre rapport gratuit avec cet email.',
      limitReachedMonth: 'Vous avez déjà utilisé votre rapport gratuit ce mois-ci.',
      subscribe: 'Abonnez-vous à l\'un de nos plans pour générer plus de rapports.',
    },
    // Confirmation Modal
    confirmationModal: {
      title: 'Demande reçue !',
      subtitle: 'Votre rapport gratuit est en cours de génération',
      confirmationEmail: 'Email de confirmation',
      deliveryTime: 'Délai de livraison',
      deliveryMinutes: '12 à 14 minutes',
      company: 'Entreprise',
      close: 'Fermer',
      checkSpam: '✓ Vérifiez votre email (y compris le dossier spam) pour recevoir votre rapport d\'intelligence B2B complet.',
      closeMessage: 'Vous pouvez fermer cette fenêtre. Votre rapport sera envoyé à',
    },
    // Pricing
    pricing: {
      title: 'Plans de tarification simples et transparents',
      subtitle: 'Choisissez le plan qui correspond à vos besoins',
      starter: 'Starter',
      starterPrice: '$97',
      starterDesc: 'Parfait pour commencer',
      professional: 'Professional',
      professionalPrice: '$197',
      professionalDesc: 'Pour les équipes de vente actives',
      enterprise: 'Enterprise',
      enterprisePrice: 'Sur mesure',
      enterpriseDesc: 'Solutions personnalisées',
      monthlyBilling: '/mois',
      features: {
        reportsMonth: 'rapports par mois',
        reportsYear: 'rapports par an',
        emailSupport: 'Support par email',
        prioritySupport: 'Support prioritaire',
        customReports: 'Rapports personnalisés',
        apiAccess: 'Accès API',
        dedicatedAccount: 'Gestionnaire de compte dédié',
      },
      subscribe: 'S\'abonner',
      contactSales: 'Contacter les ventes',
    },
    // Trust & Security
    trust: {
      title: 'Confiance et sécurité',
      payments: 'Paiements sécurisés',
      paymentsDesc: 'Traitements Stripe certifiés PCI DSS pour la sécurité maximale.',
      transparency: 'Transparence IA',
      transparencyDesc: 'Tous les rapports sont générés par IA à partir de sources publiques.',
      privacy: 'Confidentialité des données',
      privacyDesc: 'Vos données ne sont jamais partagées ou vendues à des tiers.',
    },
    // Legal Disclaimer
    disclaimer: {
      title: 'Avertissement légal important',
      aiGenerated: 'Intelligence générée par IA :',
      aiGeneratedText: 'Tous les rapports de leads, analyses et insights fournis par cette plateforme sont générés par des systèmes d\'intelligence artificielle utilisant des informations accessibles au public provenant d\'Internet et d\'autres sources ouvertes. Les informations sont fournies "telles quelles" sans garantie d\'aucune sorte, expresse ou implicite.',
      noApproval: 'Pas d\'approbation ou de vérification :',
      noApprovalText: 'Les résultats, recommandations et l\'intelligence générée par notre IA ne représentent pas les vues, opinions ou positions de Sales Runner, de ses propriétaires, opérateurs ou affiliés. Nous n\'approuvons pas, ne vérifions pas et ne garantissons pas l\'exactitude, l\'exhaustivité ou la fiabilité d\'aucun contenu généré par l\'IA.',
      userResponsibility: 'Responsabilité de l\'utilisateur :',
      userResponsibilityText: 'Les utilisateurs sont seuls responsables de la vérification de toutes les informations avant de prendre des décisions commerciales ou d\'initier un contact avec des prospects. Cette plateforme fournit des outils de génération de leads et d\'intelligence, non des conseils commerciaux ou juridiques.',
      noLiability: 'Pas de responsabilité :',
      noLiabilityText: 'Sales Runner ne sera pas responsable des décisions prises, des actions entreprises, des résultats commerciaux ou des conséquences découlant de l\'utilisation de rapports de leads générés par l\'IA. Les informations peuvent être incomplètes, obsolètes ou inexactes malgré nos meilleurs efforts.',
      compliance: 'Conformité :',
      complianceText: 'Les utilisateurs doivent se conformer à toutes les lois et réglementations applicables lors de l\'utilisation de ce service, y compris les lois sur la protection des données (RGPD, CCPA), les réglementations de confidentialité, les lois anti-spam (CAN-SPAM, CASL) et les réglementations de démarchage commercial dans leur juridiction.',
      ip: 'Propriété intellectuelle :',
      ipText: 'Les rapports de leads sont concédés sous licence pour un usage commercial interne uniquement par l\'utilisateur acheteur. La redistribution, la revente, le partage public ou la reproduction de rapports est strictement interdite sans consentement écrit.',
      noGuarantee: 'Pas de résultats garantis :',
      noGuaranteeText: 'La qualité des leads, les taux de réponse et les résultats commerciaux peuvent varier. Nous ne garantissons pas la conversion des leads, les résultats de vente ou le ROI de l\'utilisation de notre service.',
    },
    // Footer
    footer: {
      copyright: '© 2026 Sales Runner. Tous droits réservés.',
      privacy: 'Confidentialité',
      terms: 'Conditions',
      contact: 'Contact',
    },
  },
  en: {
    // Navigation
    nav: {
      howItWorks: 'How It Works',
      pricing: 'Pricing',
      dashboard: 'Dashboard',
      login: 'Sign In',
      logout: 'Sign Out',
      profile: 'Profile',
    },
    // Hero Section
    hero: {
      title: 'Account Acquisition Intelligence for',
      titleHighlight: 'Industrial Manufacturers',
      subtitle: 'Get qualified B2B leads with in-depth intelligence reports. Designed specifically for manufacturers, distributors, and industrial equipment suppliers.',
      cta: 'Get Your Free Report',
      guidedTour: 'Guided Tour',
      aiPowered: 'AI-Powered Analysis',
      industryIntel: 'Industry-Specific Intelligence',
    },
    // Value Proposition
    valueProps: {
      title: 'What We Offer',
      leads: {
        title: 'Qualified B2B Leads',
        desc: 'Detailed reports with key decision-maker profiles and outreach strategies.',
      },
      intelligence: {
        title: 'In-Depth Intelligence',
        desc: 'Complete BANT+ analysis with lead qualification assessment.',
      },
      speed: {
        title: 'Fast Delivery',
        desc: 'Reports generated in 12-14 minutes with actionable insights.',
      },
    },
    // How It Works
    howItWorks: {
      title: 'How It Works',
      step1: 'Provide Your Website',
      step1Desc: 'Give us your website URL or some information about your company.',
      step2: 'Our AI Analyzes',
      step2Desc: 'Our system finds and analyzes ideal prospects for your offer.',
      step3: 'Receive Your Reports',
      step3Desc: 'Detailed reports with outreach strategies in 12-14 minutes.',
    },
    // Free Lead Form
    freeLeadForm: {
      title: 'Get Your Free Report',
      subtitle: 'Experience Sales Runner\'s AI intelligence with a free short-form report',
      companyName: 'Your Company Name',
      companyNamePlaceholder: 'Ex: Acme Manufacturing',
      contactName: 'Your Name',
      contactNamePlaceholder: 'Ex: John Smith',
      email: 'Email',
      emailPlaceholder: 'your@email.com',
      idealCustomer: 'Your Ideal Customer (optional)',
      idealCustomerPlaceholder: 'Ex: Food processing plants',
      privacy: '✓ Your information is secure and will never be shared. No credit card required.',
      submit: 'Generate My Free Report',
      submitting: 'Generating...',
      limitReached: 'Limit Reached',
      limitReachedEmail: 'You\'ve already used your free report with this email.',
      limitReachedMonth: 'You\'ve already used your free report this month.',
      subscribe: 'Subscribe to one of our plans to generate more reports.',
    },
    // Confirmation Modal
    confirmationModal: {
      title: 'Request Received!',
      subtitle: 'Your free report is being generated',
      confirmationEmail: 'Confirmation Email',
      deliveryTime: 'Delivery Time',
      deliveryMinutes: '12 to 14 minutes',
      company: 'Company',
      close: 'Close',
      checkSpam: '✓ Check your email (including spam folder) to receive your complete B2B intelligence report.',
      closeMessage: 'You can close this window. Your report will be sent to',
    },
    // Pricing
    pricing: {
      title: 'Simple and Transparent Pricing Plans',
      subtitle: 'Choose the plan that fits your needs',
      starter: 'Starter',
      starterPrice: '$97',
      starterDesc: 'Perfect to get started',
      professional: 'Professional',
      professionalPrice: '$197',
      professionalDesc: 'For active sales teams',
      enterprise: 'Enterprise',
      enterprisePrice: 'Custom',
      enterpriseDesc: 'Personalized solutions',
      monthlyBilling: '/month',
      features: {
        reportsMonth: 'reports per month',
        reportsYear: 'reports per year',
        emailSupport: 'Email support',
        prioritySupport: 'Priority support',
        customReports: 'Custom reports',
        apiAccess: 'API access',
        dedicatedAccount: 'Dedicated account manager',
      },
      subscribe: 'Subscribe',
      contactSales: 'Contact Sales',
    },
    // Trust & Security
    trust: {
      title: 'Trust and Security',
      payments: 'Secure Payments',
      paymentsDesc: 'PCI DSS certified Stripe processing for maximum security.',
      transparency: 'AI Transparency',
      transparencyDesc: 'All reports are generated by AI from public sources.',
      privacy: 'Data Privacy',
      privacyDesc: 'Your data is never shared or sold to third parties.',
    },
    // Legal Disclaimer
    disclaimer: {
      title: 'Important Legal Disclaimer',
      aiGenerated: 'AI-Generated Intelligence:',
      aiGeneratedText: 'All lead reports, analyses, and insights provided by this platform are generated by artificial intelligence systems using publicly accessible information from the Internet and other open sources. Information is provided "as is" without any warranty of any kind, express or implied.',
      noApproval: 'No Endorsement or Verification:',
      noApprovalText: 'The results, recommendations, and intelligence generated by our AI do not represent the views, opinions, or positions of Sales Runner, its owners, operators, or affiliates. We do not endorse, verify, or guarantee the accuracy, completeness, or reliability of any AI-generated content.',
      userResponsibility: 'User Responsibility:',
      userResponsibilityText: 'Users are solely responsible for verifying all information before making business decisions or initiating contact with prospects. This platform provides lead generation and intelligence tools, not business or legal advice.',
      noLiability: 'No Liability:',
      noLiabilityText: 'Sales Runner will not be liable for decisions made, actions taken, business results, or consequences arising from the use of AI-generated lead reports. Information may be incomplete, outdated, or inaccurate despite our best efforts.',
      compliance: 'Compliance:',
      complianceText: 'Users must comply with all applicable laws and regulations when using this service, including data protection laws (GDPR, CCPA), privacy regulations, anti-spam laws (CAN-SPAM, CASL), and telemarketing regulations in their jurisdiction.',
      ip: 'Intellectual Property:',
      ipText: 'Lead reports are licensed for internal business use only by the purchasing user. Redistribution, resale, public sharing, or reproduction of reports is strictly prohibited without written consent.',
      noGuarantee: 'No Guaranteed Results:',
      noGuaranteeText: 'Lead quality, response rates, and business results may vary. We do not guarantee lead conversion, sales results, or ROI from using our service.',
    },
    // Footer
    footer: {
      copyright: '© 2026 Sales Runner. All rights reserved.',
      privacy: 'Privacy',
      terms: 'Terms',
      contact: 'Contact',
    },
  },
};

export function getTranslation(lang: Language, key: string): string {
  const keys = key.split('.');
  let value: any = translations[lang];
  
  for (const k of keys) {
    value = value?.[k];
  }
  
  return value || key;
}

export function t(lang: Language, key: string): string {
  return getTranslation(lang, key);
}
