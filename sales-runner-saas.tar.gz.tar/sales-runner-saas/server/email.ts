/**
 * Email Service
 * Handles sending emails using Manus Forge API
 */

import { ENV } from "./_core/env";

export interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  attachments?: Array<{
    filename: string;
    content: Buffer | string;
    contentType?: string;
  }>;
}

/**
 * Send email using Manus Forge API
 */
export async function sendEmail(options: EmailOptions): Promise<boolean> {
  try {
    if (!ENV.forgeApiUrl || !ENV.forgeApiKey) {
      console.warn("[Email] Forge API not configured");
      return false;
    }

    const formData = new FormData();
    formData.append("to", options.to);
    formData.append("subject", options.subject);
    formData.append("html", options.html);

    // Add attachments if provided
    if (options.attachments && options.attachments.length > 0) {
      for (const attachment of options.attachments) {
        const blob = new Blob(
          [attachment.content],
          { type: attachment.contentType || "application/octet-stream" }
        );
        formData.append("attachments", blob, attachment.filename);
      }
    }

    const response = await fetch(`${ENV.forgeApiUrl}/email/send`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${ENV.forgeApiKey}`,
      },
      body: formData,
    });

    if (!response.ok) {
      const error = await response.text();
      console.error("[Email] Failed to send email:", error);
      return false;
    }

    console.log(`[Email] Email sent successfully to ${options.to}`);
    return true;
  } catch (error) {
    console.error("[Email] Error sending email:", error);
    return false;
  }
}

/**
 * Send report email to user
 */
export async function sendReportEmail(
  userEmail: string,
  userName: string | null,
  companyName: string,
  pdfUrl: string
): Promise<boolean> {
  const html = `
    <html>
      <body style="font-family: Arial, sans-serif; color: #333;">
        <div style="max-width: 600px; margin: 0 auto;">
          <h2>Votre rapport d'intelligence B2B est prêt</h2>
          
          <p>Bonjour ${userName || ""},</p>
          
          <p>Votre rapport d'intelligence pour <strong>${companyName}</strong> a été généré avec succès.</p>
          
          <p>Le rapport contient une analyse approfondie incluant :</p>
          <ul>
            <li>Aperçu de l'entreprise et position de marché</li>
            <li>Évaluation BANT+ (Budget, Autorité, Besoin, Timing)</li>
            <li>Verdict de qualification du lead</li>
            <li>Valeur stratégique et opportunités</li>
          </ul>
          
          <p>
            <a href="${pdfUrl}" style="display: inline-block; padding: 12px 24px; background-color: #3B82F6; color: white; text-decoration: none; border-radius: 6px; font-weight: bold;">
              Télécharger le rapport
            </a>
          </p>
          
          <p>Ce rapport est disponible dans votre tableau de bord Sales Runner.</p>
          
          <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
          
          <p style="font-size: 12px; color: #666;">
            © 2026 Sales Runner. Tous droits réservés.
          </p>
        </div>
      </body>
    </html>
  `;

  return sendEmail({
    to: userEmail,
    subject: `Rapport d'intelligence B2B - ${companyName}`,
    html,
  });
}

/**
 * Send subscription confirmation email
 */
export async function sendSubscriptionConfirmationEmail(
  userEmail: string,
  userName: string | null,
  planName: string,
  price: string
): Promise<boolean> {
  const html = `
    <html>
      <body style="font-family: Arial, sans-serif; color: #333;">
        <div style="max-width: 600px; margin: 0 auto;">
          <h2>Bienvenue sur Sales Runner</h2>
          
          <p>Bonjour ${userName || ""},</p>
          
          <p>Merci pour votre abonnement au plan <strong>${planName}</strong>.</p>
          
          <p>Votre abonnement est maintenant actif et vous pouvez commencer à générer des rapports d'intelligence B2B.</p>
          
          <h3>Détails de votre abonnement :</h3>
          <ul>
            <li><strong>Plan :</strong> ${planName}</li>
            <li><strong>Prix :</strong> ${price}/mois</li>
            <li><strong>Statut :</strong> Actif</li>
          </ul>
          
          <p>
            <a href="https://sales-runner.manus.space/dashboard" style="display: inline-block; padding: 12px 24px; background-color: #3B82F6; color: white; text-decoration: none; border-radius: 6px; font-weight: bold;">
              Accéder à votre tableau de bord
            </a>
          </p>
          
          <p>Si vous avez des questions, n'hésitez pas à nous contacter via le chat en direct.</p>
          
          <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
          
          <p style="font-size: 12px; color: #666;">
            © 2026 Sales Runner. Tous droits réservés.
          </p>
        </div>
      </body>
    </html>
  `;

  return sendEmail({
    to: userEmail,
    subject: "Bienvenue sur Sales Runner",
    html,
  });
}

/**
 * Send free report confirmation email
 */
export async function sendFreeReportConfirmationEmail(
  userEmail: string,
  companyName: string
): Promise<boolean> {
  const html = `
    <html>
      <body style="font-family: Arial, sans-serif; color: #333;">
        <div style="max-width: 600px; margin: 0 auto;">
          <h2>Votre rapport gratuit est en cours de génération</h2>
          
          <p>Merci de votre intérêt pour Sales Runner.</p>
          
          <p>Nous générons actuellement votre rapport d'intelligence pour <strong>${companyName}</strong>.</p>
          
          <p>Vous recevrez un email avec votre rapport dans les 12-14 minutes.</p>
          
          <p>En attendant, découvrez nos plans d'abonnement pour accéder à des rapports illimités :</p>
          
          <ul>
            <li><strong>Starter</strong> - $97/mois : 10 rapports/mois</li>
            <li><strong>Professional</strong> - $197/mois : 50 rapports/mois</li>
            <li><strong>Enterprise</strong> - Sur mesure : rapports illimités</li>
          </ul>
          
          <p>
            <a href="https://sales-runner.manus.space/#pricing" style="display: inline-block; padding: 12px 24px; background-color: #3B82F6; color: white; text-decoration: none; border-radius: 6px; font-weight: bold;">
              Voir les plans
            </a>
          </p>
          
          <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
          
          <p style="font-size: 12px; color: #666;">
            © 2026 Sales Runner. Tous droits réservés.
          </p>
        </div>
      </body>
    </html>
  `;

  return sendEmail({
    to: userEmail,
    subject: "Votre rapport gratuit est en cours de génération",
    html,
  });
}
