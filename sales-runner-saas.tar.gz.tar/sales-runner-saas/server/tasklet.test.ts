import { describe, expect, it, beforeEach, vi } from "vitest";
import { triggerTaskletReportGeneration, verifyTaskletCallback } from "./tasklet";

describe("Tasklet AI Integration", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    process.env.TASKLET_CALLBACK_SECRET = "2fZQVwEzCUxuZNJOqVDOIr9dxOpiUB6UmoKs2GbiH90";
  });

  describe("triggerTaskletReportGeneration", () => {
    it("should return success response with valid inputs", async () => {
      const result = await triggerTaskletReportGeneration(
        "Acme Manufacturing",
        "test@example.com",
        "Industrial automation solutions",
        ["Manufacturing", "Industrial"],
        "https://example.com/api/receive-reports"
      );

      expect(result).toHaveProperty("success");
      expect(typeof result.success).toBe("boolean");
    });

    it("should include request_id in success response", async () => {
      const result = await triggerTaskletReportGeneration(
        "Test Company",
        "contact@test.com",
        "B2B SaaS platform",
        ["Technology"],
        "https://example.com/callback"
      );

      if (result.success) {
        expect(result).toHaveProperty("request_id");
      }
    });

    it("should handle network errors gracefully", async () => {
      const result = await triggerTaskletReportGeneration(
        "Test",
        "invalid",
        "Test",
        [],
        "invalid-url"
      );

      expect(result).toHaveProperty("success");
      expect(typeof result.success).toBe("boolean");
    });

    it("should use default industries if none provided", async () => {
      const result = await triggerTaskletReportGeneration(
        "Company",
        "email@test.com",
        "Value prop",
        [],
        "https://example.com/callback"
      );

      expect(result).toBeDefined();
      expect(result).toHaveProperty("success");
    });

    it("should include all required fields in payload", async () => {
      const companyName = "Test Corp";
      const email = "test@corp.com";
      const valueProposition = "Industrial solutions";
      const industries = ["Manufacturing"];
      const callbackUrl = "https://example.com/callback";

      const result = await triggerTaskletReportGeneration(
        companyName,
        email,
        valueProposition,
        industries,
        callbackUrl
      );

      expect(result).toBeDefined();
      expect(companyName).toBe("Test Corp");
      expect(email).toBe("test@corp.com");
    });
  });

  describe("verifyTaskletCallback", () => {
    it("should return true for valid token", () => {
      const validToken = `Bearer ${process.env.TASKLET_CALLBACK_SECRET || "default_manus_secret_token"}`;
      const result = verifyTaskletCallback(validToken);
      expect(result).toBe(true);
    });

    it("should return false for invalid token", () => {
      const invalidToken = "Bearer INVALID_TOKEN";
      const result = verifyTaskletCallback(invalidToken);
      expect(result).toBe(false);
    });

    it("should return false for missing Bearer prefix", () => {
      const token = process.env.TASKLET_CALLBACK_SECRET || "default_manus_secret_token";
      const result = verifyTaskletCallback(token);
      expect(result).toBe(false);
    });

    it("should return false for empty string", () => {
      const result = verifyTaskletCallback("");
      expect(result).toBe(false);
    });

    it("should be case-sensitive", () => {
      const validToken = `Bearer ${process.env.TASKLET_CALLBACK_SECRET || "default_manus_secret_token"}`;
      const invalidToken = validToken.toUpperCase();
      const result = verifyTaskletCallback(invalidToken);
      expect(result).toBe(false);
    });
  });

  describe("Payload Structure", () => {
    it("should create valid payload structure", () => {
      const payload = {
        client: {
          company_name: "Test Company",
          email: "test@example.com",
          value_proposition: "Test value",
        },
        request: {
          num_reports: 5,
          report_format: "long" as const,
          target_industries: ["Manufacturing"],
        },
        callback: {
          url: "https://example.com/callback",
          auth_header: "Bearer TOKEN",
        },
      };

      expect(payload.client).toBeDefined();
      expect(payload.request).toBeDefined();
      expect(payload.callback).toBeDefined();
      expect(payload.request.num_reports).toBe(5);
      expect(payload.request.report_format).toBe("long");
    });

    it("should handle multiple industries", () => {
      const industries = ["Manufacturing", "Industrial", "Technology"];
      expect(industries.length).toBe(3);
      expect(industries).toContain("Manufacturing");
    });
  });

  describe("Error Handling", () => {
    it("should return response object on any input", async () => {
      const result = await triggerTaskletReportGeneration(
        "",
        "invalid-email",
        "",
        [],
        "invalid-url"
      );

      expect(result).toHaveProperty("success");
      expect(typeof result.success).toBe("boolean");
    });

    it("should include error message on failure", async () => {
      const result = await triggerTaskletReportGeneration(
        "",
        "invalid",
        "",
        [],
        ""
      );

      if (!result.success) {
        expect(result).toHaveProperty("error");
        expect(typeof result.error).toBe("string");
      }
    });
  });
});
