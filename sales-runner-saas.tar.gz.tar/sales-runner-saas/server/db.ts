import { drizzle } from "drizzle-orm/mysql2";
import { eq, and, gte } from "drizzle-orm";
import { InsertUser, users, pricingPlans, subscriptions, leadReports, freeLeadRequests, generatedReports, InsertSubscription, InsertLeadReport, InsertFreeLeadRequest } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function updateUserStripeCustomerId(userId: number, stripeCustomerId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(users).set({ stripeCustomerId }).where(eq(users.id, userId));
}

// Pricing plans queries
export async function getPricingPlans() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(pricingPlans).orderBy(pricingPlans.price);
}

export async function getPricingPlanByStripePriceId(stripePriceId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(pricingPlans).where(eq(pricingPlans.stripePriceId, stripePriceId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Subscription queries
export async function getUserSubscription(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(subscriptions).where(eq(subscriptions.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createSubscription(data: InsertSubscription) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(subscriptions).values(data);
}

// Lead reports queries
export async function getUserLeadReports(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(leadReports).where(eq(leadReports.userId, userId)).orderBy(leadReports.createdAt);
}

export async function createLeadReport(data: InsertLeadReport) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(leadReports).values(data);
}

// Free lead requests queries
export async function createFreeLeadRequest(data: InsertFreeLeadRequest) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(freeLeadRequests).values(data);
}

// Check if email has already used free report (permanent limit)
export async function hasEmailUsedFreeReport(email: string) {
  const db = await getDb();
  if (!db) return false;
  const result = await db
    .select()
    .from(freeLeadRequests)
    .where(eq(freeLeadRequests.email, email))
    .limit(1);
  return result.length > 0;
}

// Check if user has used free report this month
export async function hasUserUsedFreeReportThisMonth(userId: number) {
  const db = await getDb();
  if (!db) return false;
  
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  
  const result = await db
    .select()
    .from(freeLeadRequests)
    .where(
      and(
        eq(freeLeadRequests.userId, userId),
        gte(freeLeadRequests.createdAt, monthStart)
      )
    )
    .limit(1);
  
  return result.length > 0;
}

// Get free report usage info
export async function getFreeReportUsageInfo(email: string, userId?: number) {
  const emailUsed = await hasEmailUsedFreeReport(email);
  let userMonthlyUsed = false;
  
  if (userId) {
    userMonthlyUsed = await hasUserUsedFreeReportThisMonth(userId);
  }
  
  return {
    emailUsed,
    userMonthlyUsed,
    canUse: !emailUsed && !userMonthlyUsed,
  };
}

// Generated reports queries
export async function createGeneratedReport(data: typeof generatedReports.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(generatedReports).values(data);
  return result;
}

export async function getUserGeneratedReports(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(generatedReports).where(eq(generatedReports.userId, userId)).orderBy(generatedReports.createdAt);
}

export async function getGeneratedReportById(reportId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(generatedReports).where(eq(generatedReports.id, reportId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateGeneratedReportStatus(reportId: number, status: "pending" | "generated" | "sent" | "failed", pdfUrl?: string, pdfKey?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const updateData: Record<string, any> = { status, updatedAt: new Date() };
  if (pdfUrl) updateData.pdfUrl = pdfUrl;
  if (pdfKey) updateData.pdfKey = pdfKey;
  if (status === "sent") updateData.sentAt = new Date();
  
  await db.update(generatedReports).set(updateData).where(eq(generatedReports.id, reportId));
}


