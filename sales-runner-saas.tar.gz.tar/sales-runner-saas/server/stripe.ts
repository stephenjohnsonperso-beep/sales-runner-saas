import Stripe from "stripe";
import { ENV } from "./_core/env";

export const stripe = new Stripe(ENV.stripeSecretKey, {
  apiVersion: "2025-12-15.clover",
});

export const PRICING_PLANS = {
  starter: {
    name: "Starter",
    stripePriceId: process.env.STRIPE_STARTER_PRICE_ID || "",
    price: 97,
    features: [
      "2 heures de génération IA par mois",
      "Rapports court-forme (5-7 pages)",
      "6-10 leads qualifiés par mois",
      "Aperçu de l'entreprise et contacts clés",
      "Recommandations d'approche basiques",
      "Livraison par email en 12-14 minutes",
      "Pour 1 utilisateur",
      "Support par email",
    ],
  },
  professional: {
    name: "Professional",
    stripePriceId: process.env.STRIPE_PROFESSIONAL_PRICE_ID || "",
    price: 197,
    features: [
      "6 heures de génération IA par mois",
      "Rapports détaillés étendus (15-20 pages)",
      "20-30 leads qualifiés par mois",
      "Intelligence approfondie sur l'entreprise",
      "Stratégies d'approche détaillées",
      "Récupération d'informations techniques",
      "Analyse du paysage concurrentiel",
      "Pour jusqu'à 3 utilisateurs",
      "Livraison prioritaire (10-12 minutes)",
      "Support prioritaire",
    ],
  },
  enterprise: {
    name: "Enterprise",
    stripePriceId: process.env.STRIPE_ENTERPRISE_PRICE_ID || "",
    price: 0,
    features: [
      "Déploiement sur site (LLM local)",
      "Heures de génération illimitées",
      "Modèles IA personnalisés",
      "Solution white-label",
      "Confidentialité complète des données",
      "Formats de rapport personnalisés",
      "Intégration CRM/ventes",
      "Accès API",
      "Gestionnaire de compte dédié",
      "Utilisateurs illimités",
      "Support 24/7",
      "SLA personnalisé",
    ],
  },
};

export async function createCheckoutSession(
  userId: number,
  userEmail: string,
  userName: string | null | undefined,
  planId: string,
  origin: string
) {
  const plan = PRICING_PLANS[planId as keyof typeof PRICING_PLANS];
  if (!plan || !plan.stripePriceId) {
    throw new Error("Plan invalide");
  }

  const session = await stripe.checkout.sessions.create({
    customer_email: userEmail,
    client_reference_id: userId.toString(),
    metadata: {
      user_id: userId.toString(),
      customer_email: userEmail,
      customer_name: userName || "Unknown",
      plan_id: planId,
    },
    line_items: [
      {
        price: plan.stripePriceId,
        quantity: 1,
      },
    ],
    mode: "subscription",
    success_url: `${origin}/dashboard?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${origin}/?plan=${planId}`,
    allow_promotion_codes: true,
  });

  return session.url;
}

export async function handleCheckoutSessionCompleted(session: Stripe.Checkout.Session) {
  const userId = parseInt(session.client_reference_id || "0");
  const subscriptionId = session.subscription as string;

  if (!userId || !subscriptionId) {
    console.error("Missing userId or subscriptionId in checkout session");
    return;
  }

  // Retrieve subscription details
  const subscription = await stripe.subscriptions.retrieve(subscriptionId);

  // Update user with Stripe customer ID
  const { updateUserStripeCustomerId } = await import("./db");
  if (session.customer) {
    await updateUserStripeCustomerId(userId, session.customer as string);
  }

  console.log(`[Stripe] Subscription created for user ${userId}: ${subscriptionId}`);
}

export async function handleInvoicePaid(invoice: Stripe.Invoice) {
  console.log(`[Stripe] Invoice paid: ${invoice.id}`);
}

export async function handleSubscriptionDeleted(subscription: Stripe.Subscription) {
  console.log(`[Stripe] Subscription deleted: ${subscription.id}`);
}
