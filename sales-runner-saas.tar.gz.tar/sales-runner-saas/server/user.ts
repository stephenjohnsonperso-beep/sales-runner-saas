import { eq } from "drizzle-orm";
import { users } from "../drizzle/schema";
import { getDb } from "./db";

export interface UpdateUserInput {
  name?: string;
  email?: string;
}

/**
 * Update user profile information
 * @param userId - User ID to update
 * @param data - Data to update (name, email)
 * @returns Updated user or null if not found
 */
export async function updateUserProfile(
  userId: number,
  data: UpdateUserInput
): Promise<typeof users.$inferSelect | null> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const updateData: Record<string, unknown> = {};

  if (data.name !== undefined) {
    updateData.name = data.name || null;
  }

  if (data.email !== undefined) {
    updateData.email = data.email || null;
  }

  if (Object.keys(updateData).length === 0) {
    // No updates to make
    const result = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    return result.length > 0 ? result[0] : null;
  }

  try {
    await db.update(users).set(updateData).where(eq(users.id, userId));

    // Return updated user
    const result = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("[Database] Failed to update user profile:", error);
    throw error;
  }
}

/**
 * Get user by ID
 * @param userId - User ID to fetch
 * @returns User or null if not found
 */
export async function getUserById(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}
