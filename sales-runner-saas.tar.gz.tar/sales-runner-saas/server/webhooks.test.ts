import { describe, it, expect, beforeEach, vi } from "vitest";
import { handleTaskletReportCallback } from "./webhooks";
import type { Request, Response } from "express";

describe("Tasklet Webhook Handler", () => {
  let mockReq: Partial<Request>;
  let mockRes: any;

  beforeEach(() => {
    // Ensure environment variable is set
    process.env.TASKLET_CALLBACK_SECRET = "2fZQVwEzCUxuZNJOqVDOIr9dxOpiUB6UmoKs2GbiH90";

    mockRes = {
      status: vi.fn().mockReturnThis(),
      json: vi.fn().mockReturnThis(),
    };
  });

  it("should reject requests without authorization header", async () => {
    mockReq = {
      headers: {},
      body: { request_id: "test", reports: [] },
    };

    await handleTaskletReportCallback(mockReq as Request, mockRes as Response);

    expect(mockRes.status).toHaveBeenCalledWith(401);
    expect(mockRes.json).toHaveBeenCalledWith({ error: "Unauthorized" });
  });

  it("should reject requests with invalid authorization token", async () => {
    mockReq = {
      headers: { authorization: "Bearer invalid_token" },
      body: { request_id: "test", reports: [] },
    };

    await handleTaskletReportCallback(mockReq as Request, mockRes as Response);

    expect(mockRes.status).toHaveBeenCalledWith(401);
    expect(mockRes.json).toHaveBeenCalledWith({ error: "Unauthorized" });
  });

  it("should accept requests with valid authorization token", async () => {
    mockReq = {
      headers: { authorization: "Bearer 2fZQVwEzCUxuZNJOqVDOIr9dxOpiUB6UmoKs2GbiH90" },
      body: { request_id: "test_123", reports: [] },
    };

    await handleTaskletReportCallback(mockReq as Request, mockRes as Response);

    // Note: res.json is called directly without res.status for success
    expect(mockRes.json).toHaveBeenCalledWith({ success: true, processed: 0 });
  });

  it("should reject invalid payload without request_id", async () => {
    mockReq = {
      headers: { authorization: "Bearer 2fZQVwEzCUxuZNJOqVDOIr9dxOpiUB6UmoKs2GbiH90" },
      body: { reports: [] },
    };

    await handleTaskletReportCallback(mockReq as Request, mockRes as Response);

    expect(mockRes.status).toHaveBeenCalledWith(400);
    expect(mockRes.json).toHaveBeenCalledWith({ error: "Invalid payload" });
  });

  it("should reject invalid payload without reports array", async () => {
    mockReq = {
      headers: { authorization: "Bearer 2fZQVwEzCUxuZNJOqVDOIr9dxOpiUB6UmoKs2GbiH90" },
      body: { request_id: "test_123" },
    };

    await handleTaskletReportCallback(mockReq as Request, mockRes as Response);

    expect(mockRes.status).toHaveBeenCalledWith(400);
    expect(mockRes.json).toHaveBeenCalledWith({ error: "Invalid payload" });
  });

  it("should process empty reports array successfully", async () => {
    mockReq = {
      headers: { authorization: "Bearer 2fZQVwEzCUxuZNJOqVDOIr9dxOpiUB6UmoKs2GbiH90" },
      body: { request_id: "test_123", reports: [] },
    };

    await handleTaskletReportCallback(mockReq as Request, mockRes as Response);

    // Note: res.json is called directly without res.status for success
    expect(mockRes.json).toHaveBeenCalledWith({ success: true, processed: 0 });
  });
});
