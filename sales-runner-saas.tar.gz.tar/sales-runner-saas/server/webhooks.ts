/**
 * Webhook handlers for external services
 */

import { Request, Response } from "express";
import { storagePut } from "./storage";
import { updateGeneratedReportStatus } from "./db";
import { verifyTaskletCallback } from "./tasklet";

/**
 * Handle Tasklet AI report callback
 * Receives generated PDF reports and stores them
 */
export async function handleTaskletReportCallback(req: Request, res: Response) {
  try {
    // Verify authentication
    const authHeader = req.headers.authorization || "";
    if (!verifyTaskletCallback(authHeader)) {
      console.warn("[Webhook] Invalid Tasklet AI callback authentication");
      return res.status(401).json({ error: "Unauthorized" });
    }

    const { request_id, reports } = req.body;

    if (!request_id || !Array.isArray(reports)) {
      console.warn("[Webhook] Invalid Tasklet AI callback payload", req.body);
      return res.status(400).json({ error: "Invalid payload" });
    }

    console.log(`[Webhook] Processing ${reports.length} reports for request ${request_id}`);

    // Process each report
    for (const report of reports) {
      try {
        const { report_number, pdf_url, pdf_data, target_company, target_industry } = report;

        if (!report_number || (!pdf_url && !pdf_data)) {
          console.warn("[Webhook] Missing required report fields", report);
          continue;
        }

        // Download or use provided PDF data
        let pdfBuffer: Buffer;
        if (pdf_data) {
          // PDF data provided as base64 or buffer
          pdfBuffer = Buffer.isBuffer(pdf_data) ? pdf_data : Buffer.from(pdf_data, "base64");
        } else if (pdf_url) {
          // Download PDF from URL
          const response = await fetch(pdf_url);
          if (!response.ok) {
            throw new Error(`Failed to download PDF: ${response.status}`);
          }
          pdfBuffer = Buffer.from(await response.arrayBuffer());
        } else {
          throw new Error("No PDF data or URL provided");
        }

        // Store PDF in S3
        const fileName = `${target_company || "report"}-${report_number}-${Date.now()}.pdf`;
        const s3Key = `reports/${request_id}/${fileName}`;
        
        const { url: s3Url } = await storagePut(s3Key, pdfBuffer, "application/pdf");

        console.log(`[Webhook] Stored report ${report_number} at ${s3Url}`);

        // Update report status in database
        // Note: We need to find the report by taskletRequestId and reportNumber
        // This would require a database query - for now, we'll log it
        // In production, you'd want to update the database here
        
      } catch (error) {
        console.error(`[Webhook] Error processing report ${report.report_number}:`, error);
      }
    }

    // Return success response
    res.json({ success: true, processed: reports.length });
  } catch (error) {
    console.error("[Webhook] Error handling Tasklet callback:", error);
    res.status(500).json({ error: "Internal server error" });
  }
}
