import { describe, it, expect, beforeEach, vi } from "vitest";
import { verifyTaskletCallback } from "./tasklet";

describe("Tasklet Callback Authentication", () => {
  beforeEach(() => {
    // Set the environment variable for testing
    process.env.TASKLET_CALLBACK_SECRET = "2fZQVwEzCUxuZNJOqVDOIr9dxOpiUB6UmoKs2GbiH90";
  });

  it("should verify valid callback token", () => {
    const validHeader = "Bearer 2fZQVwEzCUxuZNJOqVDOIr9dxOpiUB6UmoKs2GbiH90";
    const result = verifyTaskletCallback(validHeader);
    expect(result).toBe(true);
  });

  it("should reject invalid callback token", () => {
    const invalidHeader = "Bearer invalid_token";
    const result = verifyTaskletCallback(invalidHeader);
    expect(result).toBe(false);
  });

  it("should reject missing Bearer prefix", () => {
    const noPrefix = "2fZQVwEzCUxuZNJOqVDOIr9dxOpiUB6UmoKs2GbiH90";
    const result = verifyTaskletCallback(noPrefix);
    expect(result).toBe(false);
  });

  it("should reject empty authorization header", () => {
    const result = verifyTaskletCallback("");
    expect(result).toBe(false);
  });

  it("should handle case sensitivity correctly", () => {
    const wrongCase = "bearer 2fZQVwEzCUxuZNJOqVDOIr9dxOpiUB6UmoKs2GbiH90";
    const result = verifyTaskletCallback(wrongCase);
    expect(result).toBe(false);
  });
});
