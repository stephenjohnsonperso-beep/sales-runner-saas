import { describe, expect, it, beforeEach, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId = 1): TrpcContext {
  const user: AuthenticatedUser = {
    id: userId,
    openId: `sample-user-${userId}`,
    email: `user${userId}@example.com`,
    name: `Sample User ${userId}`,
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {
        origin: "https://sales-runner.manus.space",
      },
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {
        origin: "https://sales-runner.manus.space",
      },
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("tRPC Routers", () => {
  describe("auth.me", () => {
    it("returns null for public context", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.auth.me();
      expect(result).toBeNull();
    });

    it("returns user for authenticated context", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.auth.me();
      expect(result).toBeDefined();
      expect(result?.id).toBe(1);
      expect(result?.email).toBe("user1@example.com");
    });
  });

  describe("freeLeads.create", () => {
    it("accepts valid free lead request", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      const uniqueEmail = `test-${Date.now()}-${Math.random()
        .toString(36)
        .substring(7)}@example.com`;

      const result = await caller.freeLeads.create({
        companyName: "Test Company",
        contactName: "John Doe",
        email: uniqueEmail,
      });

      expect(result.success).toBe(true);
    });

    it("rejects invalid email", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.freeLeads.create({
          companyName: "Test Company",
          contactName: "John Doe",
          email: "invalid-email",
        });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("rejects missing required fields", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.freeLeads.create({
          companyName: "",
          contactName: "John Doe",
          email: "john@example.com",
        });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("pricing.list", () => {
    it.skip("returns pricing plans", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.pricing.list();
      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("reports.list", () => {
    it("requires authentication", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.reports.list();
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it.skip("returns reports for authenticated user", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.reports.list();
      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("subscriptions.current", () => {
    it("requires authentication", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.subscriptions.current();
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it.skip("returns subscription for authenticated user", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.subscriptions.current();
      expect(result === null || typeof result === "object").toBe(true);
    });
  });

  describe("profile.update", () => {
    it("requires authentication", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.profile.update({
          name: "New Name",
        });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it.skip("updates user profile", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.profile.update({
        name: "Updated Name",
        email: "updated@example.com",
      });

      expect(result.success).toBe(true);
      expect(result.user.name).toBe("Updated Name");
    });
  });
});
