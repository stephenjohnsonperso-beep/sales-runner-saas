/**
 * Stripe Webhook Handler
 * Processes Stripe events for subscription management
 */

import { Request, Response } from "express";
import Stripe from "stripe";
import { ENV } from "./_core/env";
import { createSubscription } from "./db";

const stripe = new Stripe(ENV.stripeSecretKey);

/**
 * Handle Stripe webhook events
 */
export async function handleStripeWebhook(req: Request, res: Response) {
  const sig = req.headers["stripe-signature"];

  if (!sig || typeof sig !== "string") {
    console.warn("[Stripe Webhook] Missing signature");
    return res.status(400).json({ error: "Missing signature" });
  }

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      ENV.stripeWebhookSecret
    );
  } catch (err) {
    console.error("[Stripe Webhook] Signature verification failed:", err);
    return res.status(400).json({ error: "Signature verification failed" });
  }

  console.log(`[Stripe Webhook] Received event: ${event.type}`);

  try {
    switch (event.type) {
      case "checkout.session.completed":
        await handleCheckoutSessionCompleted(
          event.data.object as Stripe.Checkout.Session
        );
        break;

      case "invoice.paid":
        await handleInvoicePaid(event.data.object as Stripe.Invoice);
        break;

      case "customer.subscription.updated":
        await handleSubscriptionUpdated(
          event.data.object as Stripe.Subscription
        );
        break;

      case "customer.subscription.deleted":
        await handleSubscriptionDeleted(
          event.data.object as Stripe.Subscription
        );
        break;

      default:
        console.log(`[Stripe Webhook] Unhandled event type: ${event.type}`);
    }

    res.json({ received: true });
  } catch (error) {
    console.error("[Stripe Webhook] Error processing event:", error);
    res.status(500).json({ error: "Internal server error" });
  }
}

/**
 * Handle checkout.session.completed event
 */
async function handleCheckoutSessionCompleted(
  session: Stripe.Checkout.Session
) {
  console.log(
    `[Stripe] Checkout completed for customer: ${session.customer}`
  );

  // Get client reference ID (user ID)
  const userId = session.client_reference_id
    ? parseInt(session.client_reference_id)
    : null;

  if (!userId) {
    console.warn("[Stripe] No user ID in checkout session");
    return;
  }

  // Get subscription ID from session
  const subscriptionId = session.subscription as string | null;

  if (!subscriptionId) {
    console.warn("[Stripe] No subscription ID in checkout session");
    return;
  }

  try {
    // Fetch subscription details from Stripe
    const subscription = await stripe.subscriptions.retrieve(subscriptionId);

    // Get plan ID from subscription
    const planId = subscription.items.data[0]?.plan.id;

    if (!planId) {
      console.warn("[Stripe] No plan ID in subscription");
      return;
    }

    // Create subscription in database
    const currentPeriodStart = (subscription as any).current_period_start;
    const currentPeriodEnd = (subscription as any).current_period_end;

    await createSubscription({
      userId,
      planId: 1,
      stripeSubscriptionId: subscriptionId,
      status: (subscription.status as any) || "active",
      currentPeriodStart: new Date(currentPeriodStart * 1000),
      currentPeriodEnd: new Date(currentPeriodEnd * 1000),
    });

    console.log(
      `[Stripe] Subscription created for user ${userId}: ${subscriptionId}`
    );
  } catch (error) {
    console.error("[Stripe] Error handling checkout.session.completed:", error);
  }
}

/**
 * Handle invoice.paid event
 */
async function handleInvoicePaid(invoice: Stripe.Invoice) {
  console.log(`[Stripe] Invoice paid: ${invoice.id}`);

  // Update subscription status if needed
  if ((invoice as any).subscription) {
    const subscriptionId = (invoice as any).subscription as string;
    console.log(`[Stripe] Associated subscription: ${subscriptionId}`);
  }
}

/**
 * Handle customer.subscription.updated event
 */
async function handleSubscriptionUpdated(subscription: Stripe.Subscription) {
  console.log(
    `[Stripe] Subscription updated: ${subscription.id}, status: ${subscription.status}`
  );
}

/**
 * Handle customer.subscription.deleted event
 */
async function handleSubscriptionDeleted(subscription: Stripe.Subscription) {
  console.log(`[Stripe] Subscription deleted: ${subscription.id}`);
}
