import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getPricingPlans, getUserSubscription, getUserLeadReports, createFreeLeadRequest, getFreeReportUsageInfo, createGeneratedReport, getUserGeneratedReports } from "./db";
import { createCheckoutSession } from "./stripe";
import { triggerTaskletReportGeneration } from "./tasklet";
import { updateUserProfile } from "./user";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Pricing plans router
  pricing: router({
    list: publicProcedure.query(async () => {
      return getPricingPlans();
    }),
  }),

  // Subscriptions router
  subscriptions: router({
    current: protectedProcedure.query(async ({ ctx }) => {
      return getUserSubscription(ctx.user.id);
    }),
  }),

  // Lead reports router
  reports: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return getUserLeadReports(ctx.user.id);
    }),
  }),

  // Free lead requests router
  freeLeads: router({
    checkLimit: publicProcedure
      .input(z.object({
        email: z.string().email(),
      }))
      .query(async ({ input }) => {
        return getFreeReportUsageInfo(input.email);
      }),

    create: publicProcedure
      .input(z.object({
        email: z.string().email(),
        companyName: z.string().min(1),
        contactName: z.string().min(1),
      }))
      .mutation(async ({ input }) => {
        const usageInfo = await getFreeReportUsageInfo(input.email);
        if (!usageInfo.canUse) {
          throw new Error("Free report limit reached for this email");
        }

        await createFreeLeadRequest({
          email: input.email,
          companyName: input.companyName,
          contactName: input.contactName,
        });

        return {
          success: true,
          message: "Free report request created successfully",
        };
      }),
  }),

  // Stripe router
  stripe: router({
    createCheckout: protectedProcedure
      .input(z.object({
        priceId: z.string(),
        planName: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const sessionUrl = await createCheckoutSession(
          ctx.user.id,
          ctx.user.email || "",
          ctx.user.name || "",
          input.priceId,
          ctx.req.headers.origin || "https://sales-runner.manus.space"
        );

        return {
          success: true,
          checkoutUrl: sessionUrl,
        };
      }),
  }),

  // Generated reports router (Tasklet AI integration)
  generatedReports: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return getUserGeneratedReports(ctx.user.id);
    }),

    trigger: protectedProcedure
      .input(z.object({
        companyName: z.string().min(1),
        email: z.string().email(),
        valueProposition: z.string().min(1),
        targetIndustries: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const callbackUrl = `${ctx.req.headers.origin || "https://sales-runner.manus.space"}/api/receive-reports`;
        
        const result = await triggerTaskletReportGeneration(
          input.companyName,
          input.email,
          input.valueProposition,
          input.targetIndustries || [],
          callbackUrl
        );

        if (!result.success) {
          throw new Error(result.error || "Failed to trigger report generation");
        }

        // Create pending report records
        for (let i = 1; i <= 5; i++) {
          await createGeneratedReport({
            userId: ctx.user.id,
            targetCompany: input.companyName,
            targetIndustry: input.targetIndustries?.[0] || "Industrial",
            reportNumber: i,
            status: "pending",
            taskletRequestId: result.request_id,
          });
        }

        return {
          success: true,
          message: "Report generation triggered",
          requestId: result.request_id,
        };
      }),
  }),

  // User profile router
  profile: router({
    update: protectedProcedure
      .input(z.object({
        name: z.string().optional(),
        email: z.string().email().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const updatedUser = await updateUserProfile(ctx.user.id, input);
        if (!updatedUser) {
          throw new Error("User not found");
        }
        return {
          success: true,
          user: updatedUser,
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
