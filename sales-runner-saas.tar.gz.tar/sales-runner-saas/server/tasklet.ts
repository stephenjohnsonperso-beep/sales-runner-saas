/**
 * Tasklet AI Integration
 * Handles communication with Tasklet AI webhook for generating B2B lead reports
 */

import { ENV } from "./_core/env";

const TASKLET_WEBHOOK_URL = "https://webhooks.tasklet.ai/v1/public/webhook?token=10c191a01ef6c89895c08ab5d1556481";

export interface TaskletReportRequest {
  client: {
    company_name: string;
    email: string;
    value_proposition: string;
  };
  request: {
    num_reports: number;
    report_format: "short" | "long";
    target_industries: string[];
  };
  callback: {
    url: string;
    auth_header: string;
  };
}

export interface TaskletReportResponse {
  success: boolean;
  request_id?: string;
  message?: string;
  error?: string;
}

/**
 * Trigger report generation on Tasklet AI
 * @param companyName - Name of the company to research
 * @param email - Email of the user requesting the report
 * @param valueProposition - What the client sells (for matchmaking)
 * @param industries - Target industries to search
 * @param callbackUrl - URL where Tasklet AI should send the generated reports
 * @returns Tasklet request ID or error
 */
export async function triggerTaskletReportGeneration(
  companyName: string,
  email: string,
  valueProposition: string,
  industries: string[],
  callbackUrl: string
): Promise<TaskletReportResponse> {
  try {
    const payload: TaskletReportRequest = {
      client: {
        company_name: companyName,
        email: email,
        value_proposition: valueProposition,
      },
      request: {
        num_reports: 5,
        report_format: "long",
        target_industries: industries.length > 0 ? industries : ["Manufacturing", "Industrial"],
      },
      callback: {
        url: callbackUrl,
        auth_header: `Bearer ${process.env.TASKLET_CALLBACK_SECRET || "default_manus_secret_token"}`,
      },
    };

    console.log("[Tasklet] Sending report generation request:", {
      company: companyName,
      email: email,
      industries: industries,
    });

    const response = await fetch(TASKLET_WEBHOOK_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const error = await response.text();
      console.error("[Tasklet] Error response:", error);
      return {
        success: false,
        error: `Tasklet AI error: ${response.status} ${error}`,
      };
    }

    const data = (await response.json()) as TaskletReportResponse;
    console.log("[Tasklet] Report generation triggered:", data);

    return {
      success: true,
      request_id: data.request_id,
      message: data.message || "Report generation started",
    };
  } catch (error) {
    console.error("[Tasklet] Failed to trigger report generation:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

/**
 * Verify Tasklet AI callback webhook authentication
 * @param authHeader - Authorization header from the callback
 * @returns true if valid, false otherwise
 */
export function verifyTaskletCallback(authHeader: string): boolean {
  const expectedToken = process.env.TASKLET_CALLBACK_SECRET || "default_manus_secret_token";
  const expectedHeader = `Bearer ${expectedToken}`;
  return authHeader === expectedHeader;
}
