CREATE TABLE `generated_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`freeLeadRequestId` int,
	`targetCompany` varchar(255) NOT NULL,
	`targetIndustry` varchar(255),
	`reportNumber` int,
	`pdfUrl` text,
	`pdfKey` text,
	`status` enum('pending','generated','sent','failed') NOT NULL DEFAULT 'pending',
	`taskletRequestId` varchar(255),
	`sentAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `generated_reports_id` PRIMARY KEY(`id`)
);
