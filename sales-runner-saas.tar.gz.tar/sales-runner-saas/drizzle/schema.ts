import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Pricing plans table
export const pricingPlans = mysqlTable("pricing_plans", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(), // "Starter", "Professional", "Enterprise"
  stripePriceId: varchar("stripePriceId", { length: 255 }).notNull().unique(),
  stripeProductId: varchar("stripeProductId", { length: 255 }).notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(), // 97.00, 197.00, etc.
  billingPeriod: varchar("billingPeriod", { length: 50 }).notNull(), // "month", "year"
  description: text("description"),
  features: text("features"), // JSON array of features
  maxUsers: int("maxUsers"), // null for unlimited
  maxLeadsPerMonth: int("maxLeadsPerMonth"), // null for unlimited
  aiHoursPerMonth: int("aiHoursPerMonth"), // null for unlimited
  isPopular: boolean("isPopular").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PricingPlan = typeof pricingPlans.$inferSelect;
export type InsertPricingPlan = typeof pricingPlans.$inferInsert;

// User subscriptions table
export const subscriptions = mysqlTable("subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  planId: int("planId").notNull(),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }).notNull().unique(),
  status: mysqlEnum("status", ["active", "canceled", "past_due", "trialing", "incomplete"]).notNull(),
  currentPeriodStart: timestamp("currentPeriodStart"),
  currentPeriodEnd: timestamp("currentPeriodEnd"),
  canceledAt: timestamp("canceledAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = typeof subscriptions.$inferInsert;

// Lead reports table
export const leadReports = mysqlTable("lead_reports", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  companyName: varchar("companyName", { length: 255 }).notNull(),
  contactName: varchar("contactName", { length: 255 }),
  email: varchar("email", { length: 320 }),
  reportContent: text("reportContent"), // JSON or HTML content
  status: mysqlEnum("status", ["pending", "generated", "sent", "failed"]).default("pending").notNull(),
  generatedAt: timestamp("generatedAt"),
  sentAt: timestamp("sentAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type LeadReport = typeof leadReports.$inferSelect;
export type InsertLeadReport = typeof leadReports.$inferInsert;

// Free lead requests table
export const freeLeadRequests = mysqlTable("free_lead_requests", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"), // Optional: for authenticated users
  companyName: varchar("companyName", { length: 255 }).notNull(),
  contactName: varchar("contactName", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  idealCustomer: varchar("idealCustomer", { length: 255 }),
  status: mysqlEnum("status", ["pending", "sent", "failed"]).default("pending").notNull(),
  sentAt: timestamp("sentAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FreeLeadRequest = typeof freeLeadRequests.$inferSelect;
export type InsertFreeLeadRequest = typeof freeLeadRequests.$inferInsert;
// Generated reports table (from Tasklet AI)
export const generatedReports = mysqlTable("generated_reports", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  freeLeadRequestId: int("freeLeadRequestId"), // Reference to free lead request if applicable
  targetCompany: varchar("targetCompany", { length: 255 }).notNull(),
  targetIndustry: varchar("targetIndustry", { length: 255 }),
  reportNumber: int("reportNumber"), // 1-5 for multiple reports
  pdfUrl: text("pdfUrl"), // S3 URL to the PDF
  pdfKey: text("pdfKey"), // S3 key for the PDF
  status: mysqlEnum("status", ["pending", "generated", "sent", "failed"]).default("pending").notNull(),
  taskletRequestId: varchar("taskletRequestId", { length: 255 }), // For tracking with Tasklet AI
  sentAt: timestamp("sentAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type GeneratedReport = typeof generatedReports.$inferSelect;
export type InsertGeneratedReport = typeof generatedReports.$inferInsert;
